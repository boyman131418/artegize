import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Instagram, Users, Clock, Zap, MousePointerClick, Heart, MessageCircle, BarChart3 } from 'lucide-react';

const IGGrowthDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.igGrowth || TRANSLATIONS['en'].diagrams?.igGrowth;

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-12 relative overflow-hidden">
        
        {/* Background Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-lg bg-brand-primary/20 blur-[100px] rounded-full pointer-events-none"></div>

        <div className="relative z-10 flex flex-col items-center text-center">
          
          {/* Floating Social Icons - Animated */}
          <div className="absolute top-0 left-4 md:left-10 animate-float-slow opacity-60">
            <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-md border border-white/10">
              <MessageCircle size={24} className="text-brand-accent" />
            </div>
          </div>
          <div className="absolute bottom-20 right-4 md:right-10 animate-float-delayed opacity-60">
             <div className="bg-white/10 p-3 rounded-2xl backdrop-blur-md border border-white/10">
              <Heart size={24} className="text-red-500" />
            </div>
          </div>
           <div className="absolute top-10 right-10 md:right-20 animate-pulse-slow opacity-40">
             <div className="bg-white/5 p-2 rounded-full">
              <MousePointerClick size={20} className="text-white" />
            </div>
          </div>

          {/* Central Icon & Title */}
          <div className="mb-6 relative group">
            <div className="absolute inset-0 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 rounded-3xl blur-xl opacity-50 group-hover:opacity-80 transition-opacity duration-500"></div>
            <div className="relative w-24 h-24 bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-lg">
              <Instagram size={60} color="white" strokeWidth={1.5} />
            </div>
          </div>

          <h2 className="text-2xl md:text-3xl font-bold text-white mb-2 tracking-wide uppercase">
            {t?.systemTitle}
          </h2>
          
          <div className="h-1 w-20 bg-gradient-to-r from-brand-primary to-brand-accent rounded-full mb-8"></div>

          {/* Main Stats - Big Impact */}
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-12 w-full mb-10">
            
            {/* Stat 1: Views */}
            <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm hover:bg-white/10 transition-colors w-full max-w-xs">
              <div className="flex items-center justify-center mb-3">
                <BarChart3 className="text-brand-primary mr-2" size={24} />
                <span className="text-gray-400 text-sm uppercase tracking-wider">{language === 'en' ? 'Reach' : '觸及率'}</span>
              </div>
              <div className="text-3xl md:text-4xl font-black text-white mb-1">
                {language === 'en' ? 'Millions' : '數百萬'}
              </div>
              <div className="text-xs text-gray-500 uppercase">
                {language === 'en' ? 'Monthly Views' : '每月觀看'}
              </div>
            </div>

             {/* Stat 2: 24/7 */}
             <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm hover:bg-white/10 transition-colors w-full max-w-xs">
              <div className="flex items-center justify-center mb-3">
                <Clock className="text-brand-secondary mr-2" size={24} />
                <span className="text-gray-400 text-sm uppercase tracking-wider">{language === 'en' ? 'Operation' : '運作時間'}</span>
              </div>
              <div className="text-3xl md:text-4xl font-black text-white mb-1">
                {t?.hours}
              </div>
              <div className="text-xs text-gray-500 uppercase">
                {language === 'en' ? 'Non-stop Growth' : '全天候增長'}
              </div>
            </div>

          </div>

          {/* Bottom Banner / Callout */}
          <div className="w-full max-w-2xl bg-gradient-to-r from-brand-primary/20 to-brand-accent/20 border border-brand-primary/30 rounded-xl p-4 flex items-center justify-center gap-3">
            <Zap className="text-yellow-400 fill-yellow-400" size={20} />
            <p className="text-white font-medium text-lg">
              {t?.autoRun} • <span className="text-brand-accent">{t?.clients}</span>
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default IGGrowthDiagram;

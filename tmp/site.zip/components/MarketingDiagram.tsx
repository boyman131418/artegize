import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { BrainCircuit, Share2, Megaphone, FileText, BarChart2, Zap } from 'lucide-react';

const MarketingDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.marketing || TRANSLATIONS['en'].diagrams?.marketing;

  // Map icons to the 4 channels
  const icons = [Share2, Megaphone, FileText, BarChart2];
  
  // Positions for the 4 nodes (Top, Right, Bottom, Left)
  const positions = [
    'top-0 left-1/2 -translate-x-1/2 -translate-y-1/2', // Top
    'top-1/2 right-0 translate-x-1/2 -translate-y-1/2', // Right
    'bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2', // Bottom
    'top-1/2 left-0 -translate-x-1/2 -translate-y-1/2', // Left
  ];

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-16 relative overflow-hidden min-h-[500px] flex flex-col items-center justify-center">
        
        {/* Background Glows */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-lg bg-brand-primary/10 blur-[120px] rounded-full pointer-events-none"></div>

        <div className="relative z-10 w-full max-w-3xl">
          <h3 className="text-2xl md:text-4xl font-extrabold text-center mb-16 text-white tracking-tight uppercase drop-shadow-lg">
            {t?.title}
          </h3>
          
          <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto">
            {/* Connecting Lines (Cross) */}
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-brand-primary/30 to-transparent -translate-y-1/2"></div>
            <div className="absolute top-0 left-1/2 w-0.5 h-full bg-gradient-to-b from-transparent via-brand-primary/30 to-transparent -translate-x-1/2"></div>
            
            {/* Center Core (AI Brain) */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
              <div className="relative group">
                <div className="w-24 h-24 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-2xl flex flex-col items-center justify-center shadow-2xl border border-white/20 relative z-10">
                  <BrainCircuit size={40} className="text-white mb-1" />
                  <span className="text-[10px] font-bold text-white uppercase tracking-widest">{t?.core}</span>
                </div>
              </div>
            </div>

            {/* Satellite Nodes */}
            {t?.channels.map((channel: string, index: number) => {
              const Icon = icons[index];
              return (
                <div 
                  key={index}
                  className={`absolute ${positions[index]} z-20 flex flex-col items-center group`}
                >
                  <div className="w-16 h-16 bg-brand-dark border border-brand-primary/30 rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:border-brand-accent transition-all duration-300 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <Icon size={24} className="text-gray-300 group-hover:text-white transition-colors" />
                  </div>
                  <div className="mt-3 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10">
                    <span className="text-xs font-bold text-gray-200 whitespace-nowrap">{channel}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Integration Label */}
          <div className="text-center mt-16">
             <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-brand-accent text-sm font-medium">
                <Zap size={16} className="fill-brand-accent" />
                <span>Fully Integrated Ecosystem</span>
             </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default MarketingDiagram;

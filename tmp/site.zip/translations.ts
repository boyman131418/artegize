export const TRANSLATIONS = {
  en: {
    nav: {
      home: "Home",
      services: "Services",
      portfolio: "Portfolio",
      accountSales: "Buy Accounts",
      about: "About Us",
      clients: "Our Clients",
      contact: "Contact",
      dashboard: "Dashboard",
      login: "Login",
      logout: "Logout"
    },
    about: {
        title: "About Artegize: Where Creativity Meets Strategy",
        subtitle: "Where Art Meets Strategy.",
        origin: {
            title: "Our Origin",
            content: "In the ever-changing world of digital marketing, \"Artegize\" was born from a core belief: the perfect fusion of \"Art\" and \"Strategize\". We believe creativity without strategy is vanity, and strategy without creativity is dull. Artegize aims to break the mold of traditional agencies with high fees and slow responses. We infuse compelling visuals and copy (Art) into precise data analysis and growth logic (Strategize), ensuring every marketing action translates into tangible business returns."
        },
        whoWeAre: {
            title: "Who We Are",
            content: "We are not traditional social media editors; we are your **\"AI-Driven Growth Engine.\"** As Hong Kong's leading AI marketing and Growth Hacking team, Artegize leverages cutting-edge AI technology to deliver superior marketing efficiency. From precise AI content matrices to real organic traffic growth, we power your brand with technology."
        },
        philosophy: {
            title: "Our Core Philosophy",
            items: [
                {
                    title: "Real Organic Growth",
                    description: "In an era of fake followers, we insist on **\"Real Traffic.\"** Using AI to capture trends, we attract 100% genuine audiences interested in your product to your IG and Threads. Only real engagement brings real sales."
                },
                {
                    title: "The Ultimate O2O Ecosystem",
                    description: "We uniquely combine **\"Online AI Growth\" with \"Offline Physical Networks.\"** Integrating our Gift & Premium network and Offline Events experience, we convert offline foot traffic into long-term digital assets using AI interaction."
                },
                {
                    title: "Tech-Driven Efficiency",
                    description: "We use AI to shorten content production from days to minutes. This allows us to provide higher frequency and quality content at competitive prices, giving startups and SMEs top-tier marketing power."
                }
            ]
        },
        mission: {
            title: "Our Mission",
            content: "Whether you are a startup sports brand, an education institution, or a B2B enterprise, Artegize has one mission: \"To turn your business vision into reality with the speed and precision of AI.\""
        }
    },
    hero: {
      title1: "Transform Your Marketing",
      title2: "With Artificial Intelligence",
      description: "Artegize bridges the gap between creativity and technology. We manage 200+ IG accounts, provide expert AI workshops, and deliver data-driven strategies for the modern age.",
      cta_explore: "Explore Services",
      cta_quote: "Get a Quote"
    },
    stats: {
      accounts: "IG Accounts Managed",
      workshops: "Workshops Hosted",
      satisfaction: "Client Satisfaction",
      monitoring: "AI Monitoring"
    },
    services: {
        title: "Our Services",
        subtitle: "Comprehensive solutions from workshops to full-scale management.",
        cta: "Interested?",
        items: [
            {
                id: 's1',
                slug: 'ai-workshops',
                title: "AI Workshops",
                description: "Face-to-face training sessions to empower your team with the latest AI marketing tools and strategies.",
                icon: "fa-chalkboard-teacher",
                details: {
                    quote: "\"Equipping your internal team with an AI engine\"",
                    content: "Service Content: Providing face-to-face professional training courses to help your internal team master the latest AI marketing tools and practical strategies (including AI copywriting, image design, automated video editing, etc.).",
                    value: "Commercial Value: We help your enterprise achieve \"cost reduction and efficiency increase\", shortening the content production process from three days to one hour, significantly improving team productivity."
                }
            },
            {
                id: 's2',
                slug: 'ig-account-management',
                title: "IG Account Management",
                description: "Professional management of over 200+ accounts, ensuring consistent growth and engagement.",
                icon: "fa-chart-line",
                details: {
                    quote: "\"Building a high-frequency, all-real organic traffic matrix with AI\"",
                    content: "Service Content: Professional operation and management of over 200+ social media accounts. We use exclusive AI content systems to achieve high-frequency high-quality content output, ensuring continuous account growth and high interaction rates.",
                    value: "Commercial Value: We refuse to buy fake followers. Through precise content strategies, we attract 100% real target audiences for you, turning your IG into the most valuable private traffic pool for conversion."
                }
            },
            {
                id: 's3',
                slug: 'account-sales',
                title: "Account Sales",
                description: "Purchase established social media accounts with organic followings to jumpstart your brand presence.",
                icon: "fa-store",
                details: {
                    quote: "\"Breaking the cold start curse, winning at the starting line\"",
                    content: "Service Content: Providing social media account trading and transfer services with established stable organic traffic and precise audiences.",
                    value: "Commercial Value: Solving the \"zero fan trust crisis\" for startup brands. Directly acquiring accounts with real followers allows your advertising and content marketing to have strong \"Social Proof\" from the start."
                }
            },
            {
                id: 's4',
                slug: 'marketing-solutions',
                title: "Marketing Solutions",
                description: "Comprehensive online and offline marketing strategies tailored to your business goals.",
                icon: "fa-bullhorn",
                details: {
                    quote: "\"Your external Chief Marketing Officer (CMO)\"",
                    content: "Service Content: Deeply understanding your business goals, tailoring comprehensive marketing strategy planning across online and offline for you.",
                    value: "Commercial Value: From early market positioning, AI Chatbot customer service setup, to later cross-platform advertising layout, we provide a one-stop integrated brain ensuring every marketing action aligns with your final sales goals."
                }
            },
            {
                id: 's5',
                slug: 'gift-premium',
                title: "Gift & Premium",
                description: "Phygital B2B marketing packages using physical gifts as offline hooks for online growth, leveraging gift networks for low-cost giveaways, and reactivating B2B databases.",
                icon: "fa-gift",
                details: {
                    quote: "\"Transforming traditional procurement into the most powerful follower growth bait\"",
                    content: "Service Content: Creating innovative \"Digital + Physical\" B2B corporate marketing packages. We use high-quality physical gifts as offline bait (combined with QR Code redirection) and use our gift network for low-cost online Giveaways.",
                    value: "Commercial Value: Making gifts no longer just an expense! We turn physical items into \"follower growth engines\", precisely achieving B2B database redirection, converting offline passersby who took gifts into 100% online loyal followers."
                }
            },
            {
                id: 's6',
                slug: 'offline-event-marketing',
                title: "Offline Event & Marketing",
                description: "O2O AI marketing solutions that transform offline foot traffic into online digital assets. Capture real followers at events and automate lead generation.",
                icon: "fa-handshake",
                details: {
                    quote: "\"Say goodbye to losing customers after the event, monetize on-site traffic\"",
                    content: "Service Content: Creating an O2O (Offline to Online) AI marketing loop. We provide on-site AI interactive experiences, instant highlight video generation, and automated WhatsApp list collection systems.",
                    value: "Commercial Value: We convert every visitor who walks into your car show, sports event, or Pop-up Store into a real fan on IG or a high-potential list in the database, ensuring your event budget translates into long-term digital assets."
                }
            }
        ]
    },
    whyUs: {
        title: "Why Choose Us?",
        subtitle: "Three core advantages that distinguish us from traditional agencies.",
        items: [
            {
                title: "Organic Growth, No Fake Followers",
                description: "Unlike companies selling \"layout and design,\" we deliver **\"real traffic and conversion.\"** Leveraging data from 200+ accounts and AI, we attract genuine followers and potential customers, not fake accounts.",
                icon: "fa-rocket"
            },
            {
                title: "The True O2O Integration",
                description: "We uniquely fuse **\"Physical Gifts & Offline Events\" with \"AI Digital Growth.\"** We bridge the physical and digital worlds, turning offline interactions and gifts into your brand's exclusive online data assets.",
                icon: "fa-sync-alt"
            },
            {
                title: "Unbeatable AI Efficiency",
                description: "Traditional agencies have high labor costs. Our AI automation delivers 10x productivity, offering faster speed, higher update frequency, and competitive pricing for superior marketing results.",
                icon: "fa-robot"
            }
        ]
    },
    portfolio: {
        title: "Latest Insights & Portfolio",
        subtitle: "See how we help businesses grow with AI-driven strategies.",
        readMore: "Read more"
    },
    accountSales: {
        title: "Premium IG Accounts",
        subtitle: "Jumpstart your social media presence with our established, high-engagement accounts.",
        niche: "Niche",
        followers: "Followers",
        engagement: "Engagement",
        price: "Price",
        inquire: "Inquire / Buy",
        verified: "Verified Audience"
    },
    contact: {
        title: "Contact Us",
        subtitle: "Ready to Elevate Your Brand?",
        description: "Whether you need to buy an established account, join a workshop, or automate your marketing, Artegize is here to help.",
        infoTitle: "Contact Information",
        email: "contact@artegize.com",
        phone: "+852 9699 7127",
        address: "Shop A01-02, LG/F, The Bayview, 633 Castle Peak Road, Tsuen Wan, Hong Kong",
        namePlaceholder: "Name",
        emailPlaceholder: "Email",
        msgPlaceholder: "How can we help you?",
        submit: "Send Message"
    },
    footer: {
        tagline: "AI-Powered Marketing for the Future.",
        rights: "Artegize Marketing. All rights reserved.",
        sections: {
            services: "Services",
            company: "Company",
            contact: "Contact",
            links: {
                workshops: "AI Workshops",
                management: "IG Management",
                trading: "Account Trading",
                marketing: "Marketing Solutions",
                gift: "Gift & Premium",
                events: "Offline Events",
                about: "About Us",
                portfolio: "Portfolio",
                contact: "Contact Us",
                disclaimer: "Disclaimer"
            }
        }
    },
    disclaimer: {
        title: "Artegize Service Disclaimer",
        intro: "Welcome to Artegize (hereinafter referred to as \"the Company\"). We provide AI digital marketing, social media management, and related consulting services. To protect the rights and interests of both parties, please carefully read the following disclaimer before signing a cooperation agreement or using our services. By using our services, you acknowledge that you have fully understood and agreed to the following terms:",
        sections: [
            {
                title: "1. Social Media Platform Policy & Algorithm Risks",
                items: [
                    {
                        label: "Platform Rule Changes:",
                        content: "The IG, Threads, and other social media account management and growth services provided by the Company follow current platform algorithms and best practices for organic growth. However, third-party platforms (such as Meta, WhatsApp, etc.) have the absolute right to change their algorithms, terms of use, and community guidelines at any time."
                    },
                    {
                        label: "Account Restrictions:",
                        content: "The Company shall not be liable for any direct or indirect compensation if an account suffers from traffic restrictions, blocking, suspension, or functional limitations due to sudden changes in third-party platform policies, system failures, or the Client's own publication of content that violates platform guidelines."
                    },
                    {
                        label: "Account Transfer Risks:",
                        content: "For \"Account Sales & Activation\" services, the Company guarantees the availability of the account and the authenticity of existing data at the time of delivery. However, the ultimate ownership and interpretation rights of all social media accounts belong to the official platform. The operational risks and account continuity status after the Client takes over shall be borne by the Client."
                    }
                ]
            },
            {
                title: "2. Marketing Effectiveness & Revenue Statement",
                items: [
                    {
                        label: "Non-Guaranteed Revenue:",
                        content: "The Company is committed to using cutting-edge AI technology to optimize exposure, grow real followers, and increase engagement rates for Clients. However, all data regarding traffic growth, follower count estimates, potential lead acquisition (Lead Generation), or actual sales conversion rates are \"predictions\" and \"goals\" based on past experience and do not constitute any legally binding performance or revenue guarantees."
                    },
                    {
                        label: "Market Variables:",
                        content: "The final commercial monetization capability is subject to multiple uncontrollable factors (e.g., the market competitiveness of the Client's product, pricing strategy, macroeconomic environment, etc.). The Company is not responsible for the Client's final turnover or loss of profit."
                    }
                ]
            },
            {
                title: "3. AI System Operation & Content Output",
                items: [
                    {
                        label: "AI Content Accuracy:",
                        content: "The Company uses Artificial Intelligence (including but not limited to copywriting generation, image synthesis, automated video editing, and AI Chatbot customer service) to assist in content generation. Although the system has been optimized and trained, AI may still produce inaccurate, incomplete, or semantically biased content (i.e., \"AI Hallucinations\")."
                    },
                    {
                        label: "Client Review Obligation:",
                        content: "The Client is responsible for the final review of content before official publication. If consumer disputes arise due to information errors (including but not limited to incorrect prices, times, or product specifications) in the automatic replies of the AI customer service system (such as WhatsApp Chatbot), the Company will assist in correcting the system logic but will not be financially liable for any commercial losses caused thereby."
                    },
                    {
                        label: "Copyright & Secondary Creation:",
                        content: "The Company uses AI for content curation and secondary creation, aiming to comply with fair use principles. However, intellectual property laws and regulations are constantly evolving with technological development. Clients must assess and bear the potential copyright risks of publishing relevant synthetic content. The Company is not responsible for any claims arising from content copyright disputes."
                    }
                ]
            },
            {
                title: "4. Offline Events & Physical Gifts (O2O Marketing)",
                content: "For marketing projects combining \"Gift & Premium\" and offline events, the Company is responsible for the stable operation of online systems (such as QR Code redirection, online list collection). The Company does not assume relevant responsibility for marketing interruptions caused by factors not directly under the Company's control, such as sudden situations at the offline event venue, unstable venue networks, defects in physical gifts, or logistics delays."
            },
            {
                title: "5. Service Interruption & Force Majeure",
                content: "If the Company's AI system, automated customer service, or marketing services are interrupted due to force majeure factors (such as natural disasters, hacker attacks, telecommunications provider failures, server downtime maintenance, etc.), the Company will do its best to assist in restoring operations but does not assume any liability for losses derived during the service interruption period."
            }
        ]
    },
    admin: {
        loginTitle: "Admin Access",
        loginSubtitle: "Enter your credentials to manage content",
        passwordLabel: "Password",
        loginBtn: "Login",
        hint: "This is a protected area for Artegize staff.",
        dashboardTitle: "Admin Dashboard",
        welcome: "Welcome",
        aiAssistant: "AI Content Assistant",
        aiPlaceholder: "Enter a topic (e.g., 'Benefits of AI in SEO')",
        generate: "Generate",
        thinking: "Thinking...",
        createPost: "Create New Post",
        postTitle: "Title",
        postCategory: "Category",
        postImage: "Image",
        postExcerpt: "Excerpt (Summary)",
        postContent: "Full Content",
        publish: "Publish Post",
        manageContent: "Manage Content",
        
        // New Account Management Translations
        tabPosts: "Blog Posts",
        tabAccounts: "IG Accounts",
        tabClients: "Our Clients",
        createAccount: "List New Account",
        createClient: "Add New Client",
        clientName: "Client Name",
        clientLogo: "Logo",
        addClient: "Add Client",
        accHandle: "Account Handle",
        accNiche: "Niche",
        accFollowers: "Followers (e.g. 10k)",
        accEngagement: "Engagement (e.g. 5.5%)",
        accPrice: "Price (e.g. $500 USD)",
        accDescription: "Description",
        publishAccount: "List Account"
    },
    diagrams: {
        growth: {
            title: "Growth Comparison",
            subtitle: "Traditional Marketing vs. Artegize AI Strategy",
            traditional: "Traditional Agency",
            ai: "Artegize AI Growth"
        },
        process: {
            title: "The Artegize Workflow",
            step1: { title: "AI Strategy", desc: "Data-driven analysis & content planning" },
            step2: { title: "Automated Execution", desc: "High-frequency content & engagement" },
            step3: { title: "Real Growth", desc: "Genuine followers & business conversion" }
        },
        ecosystem: {
            title: "The O2O Growth Loop",
            center: { title: "Artegize", subtitle: "AI Core" },
            nodes: {
                online: "Online Traffic",
                fans: "Loyal Fans",
                offline: "Offline Events",
                gifts: "Physical Gifts"
            },
            steps: [
                "1. AI attracts online traffic",
                "2. Gifts drive offline engagement",
                "3. Events capture real leads",
                "4. Data feeds back to AI"
            ]
        },
        igGrowth: {
            systemTitle: "Automatic Traffic System",
            views: "Millions of Monthly Views",
            autoRun: "System runs automatically after setup",
            hours: "24 Hours",
            clients: "Attracting Precise Clients"
        },
        workshops: {
            title: "AI Mastery Path",
            steps: [
                { title: "Learn", desc: "Master AI Tools" },
                { title: "Implement", desc: "Build Workflows" },
                { title: "Grow", desc: "Scale Business" }
            ]
        },
        marketing: {
            title: "Integrated Strategy",
            core: "AI Brain",
            channels: ["Social Media", "Paid Ads", "Content", "Analytics"]
        },
        gift: {
            title: "Phygital Conversion",
            flow: ["Physical Gift", "QR Scan", "Online Follow", "Data Capture"]
        },
        event: {
            title: "Event ROI Loop",
            flow: ["Foot Traffic", "AI Interaction", "Lead Gen", "Digital Asset"]
        },
        accountSales: {
            title: "Instant Authority",
            steps: [
                { title: "Zero Wait", desc: "Skip the cold start" },
                { title: "Social Proof", desc: "Instant credibility" },
                { title: "Sales Ready", desc: "Monetize immediately" }
            ]
        }
    }
  },
  zh: {
    nav: {
      home: "首頁",
      services: "服務",
      portfolio: "案例",
      accountSales: "帳號買賣",
      about: "關於我們",
      clients: "我們的客戶",
      contact: "聯絡我們",
      dashboard: "管理後台",
      login: "登入",
      logout: "登出"
    },
    about: {
        title: "關於藝策 Artegize：當極致創意遇上精密策略",
        subtitle: "Where Art Meets Strategy.",
        origin: {
            title: "我們的起源 (Our Origin)",
            content: "在瞬息萬變的數碼營銷世界裡，「藝策 Artegize」 的誕生源於我們對一個核心理念的堅持：這是一個由 \"Art\"（藝術/創意） 與 \"Strategize\"（策略佈局） 完美融合的單詞。我們深信：沒有策略的創意只是孤芳自賞，而沒有創意的策略則枯燥乏味。Artegize 旨在打破傳統廣告公司收費高昂、反應緩慢的僵局。我們將最具渲染力的視覺與文案（Art），植入到精密計算的數據分析與增長邏輯（Strategize）之中，讓每一次的營銷行動，都能精準轉化為實實在在的商業回報。"
        },
        whoWeAre: {
            title: "我們是誰？ (Who We Are)",
            content: "我們不是傳統的「社交媒體小編」，我們是您的**「AI 驅動增長引擎」**。作為香港領先的 AI 營銷與增長黑客 (Growth Hacking) 團隊，Artegize 專注於利用最前沿的人工智能技術，為品牌實現降維打擊級別的營銷效率。從精準的 AI 內容矩陣、高互動的虛擬客服，到全真人的自然流量增長，我們用科技為您的品牌注入源源不絕的動力。"
        },
        philosophy: {
            title: "我們的核心哲學 (Our Core Philosophy)",
            items: [
                {
                    title: "拒絕虛榮數據，專注真實轉化 (Real Organic Growth)",
                    description: "在這個充斥著假粉與機器人的時代，我們堅持只做「真實流量」。透過 AI 精準抓取趨勢與內容重製，我們為您的 IG 和 Threads 吸引 100% 對您產品感興趣的真人受眾。我們深知，只有真實的互動，才能帶來真實的銷售。"
                },
                {
                    title: "獨家 O2O 營銷閉環 (The Ultimate O2O Ecosystem)",
                    description: "我們是市場上極少數能將**「線上 AI 增長」與「線下實體網絡」**完美結合的團隊。透過整合我們強大的禮品與贈品 (Gift & Premium) 網絡以及線下活動 (Offline Events) 經驗，我們能將車展、體育賽事等現場的「過客」，利用 AI 互動技術，100% 轉化為您社交媒體上的長期數位資產。"
                },
                {
                    title: "以科技實現「降本增效」 (Tech-Driven Efficiency)",
                    description: "我們利用 AI 系統將傳統需要數天的內容製作流程，縮短至幾小時甚至幾分鐘。這意味著我們能以極具競爭力的價格，為您提供更高頻率、更高質量的內容輸出，讓初創企業與中小企也能享受頂級的營銷火力。"
                }
            ]
        },
        mission: {
            title: "我們的使命 (Our Mission)",
            content: "無論您是準備冷啟動的初創運動品牌、尋求突破的體育教育機構，還是希望活化 B2B 客戶名單的企業，Artegize 的使命只有一個：「用 AI 的速度與精準，將您的商業願景化為現實。」"
        }
    },
    hero: {
      title1: "以人工智能",
      title2: "徹底轉型您的營銷策略",
      description: "Artegize 連結創意與科技。我們管理超過 200 個 IG 帳號，提供專業 AI 工作坊，並為現代企業提供數據驅動的營銷策略。",
      cta_explore: "探索服務",
      cta_quote: "獲取報價"
    },
    stats: {
      accounts: "IG 帳號管理",
      workshops: "舉辦工作坊",
      satisfaction: "客戶滿意度",
      monitoring: "AI 監測"
    },
    services: {
        title: "我們的服務",
        subtitle: "從工作坊到全方位管理的一站式解決方案。",
        cta: "有興趣嗎？",
        items: [
            {
                id: 's1',
                slug: 'ai-workshops',
                title: "AI 工作坊",
                description: "面對面培訓課程，讓您的團隊掌握最新的 AI 營銷工具和策略。",
                icon: "fa-chalkboard-teacher",
                details: {
                    quote: "「為您的內部團隊裝上 AI 引擎」",
                    content: "服務內容： 提供面對面的專業培訓課程，讓您的內部團隊熟練掌握最前沿的 AI 營銷工具與實戰策略（包括 AI 文案生成、圖像設計、自動化視頻剪輯等）。",
                    value: "商業價值： 授人以魚不如授人以漁。我們幫助您的企業實現「降本增效」，讓原本需要三天的內容製作流程縮短至一小時，大幅提升團隊產能。"
                }
            },
            {
                id: 's2',
                slug: 'ig-account-management',
                title: "IG 帳號管理",
                description: "專業管理超過 200+ 個帳號，確保持續增長和互動。",
                icon: "fa-chart-line",
                details: {
                    quote: "「用 AI 打造高頻率、全真人的自然流量矩陣」",
                    content: "服務內容： 專業代運營與管理超過 200+ 個社交媒體帳號。我們利用獨家的 AI 內容系統，實現高頻率的優質內容輸出，確保帳號持續增長和高互動率。",
                    value: "商業價值： 我們拒絕購買假粉。我們透過精準的內容策略，為您吸引 100% 的真實目標受眾，將您的 IG 變成最具轉化價值的私域流量池。"
                }
            },
            {
                id: 's3',
                slug: 'account-sales',
                title: "帳號買賣",
                description: "購買已建立自然流量的社交媒體帳號，快速啟動您的品牌。",
                icon: "fa-store",
                details: {
                    quote: "「打破冷啟動魔咒，贏在起跑線」",
                    content: "服務內容： 提供已建立穩定自然流量、具備精準受眾的社交媒體帳號買賣與轉讓服務。",
                    value: "商業價值： 解決初創品牌最痛的「零粉絲信任危機」。直接收購擁有真實粉絲的帳號，讓您的廣告投放與內容營銷一開始就具備強大的「社會證明 (Social Proof)」，極速啟動品牌影響力。"
                }
            },
            {
                id: 's4',
                slug: 'marketing-solutions',
                title: "營銷解決方案",
                description: "為您的業務目標量身定制的全面線上和線下營銷策略。",
                icon: "fa-bullhorn",
                details: {
                    quote: "「您的外掛首席營銷官 (CMO)」",
                    content: "服務內容： 深入了解您的業務目標，為您量身定制跨越線上與線下的全面營銷策略規劃。",
                    value: "商業價值： 從前期的市場定位、AI Chatbot 客服搭建，到後期的跨平台廣告佈局，我們提供一站式的整合大腦，確保每一個營銷動作都對準您的最終銷售目標。"
                }
            },
            {
                id: 's5',
                slug: 'gift-premium',
                title: "禮品與贈品",
                description: "打造「數碼 + 實體」的 B2B 企業營銷套餐。利用實體禮品作為「增粉引擎」的線下誘餌，並利用禮品網絡進行低成本 Giveaway，實現 B2B 數據庫重定向。",
                icon: "fa-gift",
                details: {
                    quote: "「將傳統採購轉化為最強大的增粉誘餌」",
                    content: "服務內容： 打造創新的「數碼 + 實體」B2B 企業營銷套餐。我們利用高品質的實體禮品作為線下誘餌（結合 QR Code 導流），並利用我們的禮品網絡進行低成本的線上 Giveaway。",
                    value: "商業價值： 讓贈品不再只是開銷！我們將實體物品變成「增粉引擎」，精準實現 B2B 數據庫重定向，將拿了禮物的線下過客，100% 轉化為線上忠實追隨者。"
                }
            },
            {
                id: 's6',
                slug: 'offline-event-marketing',
                title: "線下活動與營銷",
                description: "打造 O2O AI 營銷閉環，將線下人流轉化為線上數據資產。提供現場吸粉引擎、自動化名單收集及 AI 互動體驗，確保活動預算轉化為長期資產。",
                icon: "fa-handshake",
                details: {
                    quote: "「告別人走茶涼，將現場人流變現」",
                    content: "服務內容： 打造 O2O（Offline to Online）AI 營銷閉環。我們提供現場 AI 互動體驗、即時精華影片生成，以及自動化 WhatsApp 名單收集系統。",
                    value: "商業價值： 傳統活動結束後客戶就流失了。我們將每一位走進您車展、體育賽事或 Pop-up Store 的訪客，轉化為 IG 上的真實粉絲或數據庫中的高潛力名單，確保您的活動預算轉化為長期數位資產。"
                }
            }
        ]
    },
    whyUs: {
        title: "為什麼選擇我們？",
        subtitle: "這三個核心優勢是 Artegize 與傳統 4A 廣告公司或普通小編團隊拉開差距的關鍵：",
        items: [
            {
                title: "我們是「增長黑客」，不是發帖機器",
                description: "市面上的公司賣的是「排版和設計」，我們賣的是**「真實流量與轉化」**。我們手握 200+ 帳號的實戰數據，深諳社交媒體演算法。我們利用 AI 系統自然吸引真人粉絲，為您的品牌帶來真正會消費的潛在客戶，而不是沒有靈魂的假帳號。",
                icon: "fa-rocket"
            },
            {
                title: "獨一無二的 O2O 營銷閉環",
                description: "我們是市場上極少數能將**「實體禮品/線下活動」與「AI 數位增長」**完美融合的公司。我們不僅能在雲端幫您寫文案，更能落地到實體世界，將看得見、摸得著的禮品與現場人流，編織成您品牌專屬的線上數據網。",
                icon: "fa-sync-alt"
            },
            {
                title: "AI 賦能的「降維打擊」性價比",
                description: "傳統 Agency 收費高昂是因為依賴大量人力成本。我們透過頂尖的 AI 自動化工作流，產能是傳統團隊的十倍。這意味著我們能以更快的速度、更高的更新頻率、更具競爭力的價格，為您提供超出預期的營銷成果。",
                icon: "fa-robot"
            }
        ]
    },
    portfolio: {
        title: "最新洞察與案例",
        subtitle: "看看我們如何利用 AI 驅動策略幫助企業成長。",
        readMore: "閱讀更多"
    },
    accountSales: {
        title: "精選 IG 帳號出售",
        subtitle: "購買已建立的高互動帳號，快速啟動您的社交媒體影響力。",
        niche: "領域",
        followers: "粉絲數",
        engagement: "互動率",
        price: "價格",
        inquire: "查詢 / 購買",
        verified: "已驗證受眾"
    },
    contact: {
        title: "聯絡我們",
        subtitle: "準備好提升您的品牌了嗎？",
        description: "無論您需要購買現成帳號、參加工作坊，還是自動化您的營銷，Artegize 都能為您提供協助。",
        infoTitle: "聯絡資料",
        email: "contact@artegize.com",
        phone: "+852 9699 7127",
        address: "香港荃灣青山公路, 荃灣段633號, 灣景滙, LG, A01-02",
        namePlaceholder: "姓名",
        emailPlaceholder: "電郵",
        msgPlaceholder: "我們如何協助您？",
        submit: "發送訊息"
    },
    footer: {
        tagline: "面向未來的 AI 驅動營銷。",
        rights: "Artegize Marketing. 版權所有。",
        sections: {
            services: "服務項目",
            company: "公司資訊",
            contact: "聯絡資訊",
            links: {
                workshops: "AI 工作坊",
                management: "IG 帳號管理",
                trading: "帳號買賣",
                marketing: "營銷解決方案",
                gift: "禮品與贈品",
                events: "線下活動",
                about: "關於我們",
                portfolio: "案例展示",
                contact: "聯絡我們",
                disclaimer: "免責聲明"
            }
        }
    },
    disclaimer: {
        title: "藝策 (Artegize) 服務免責聲明",
        intro: "歡迎您使用藝策 Artegize（以下簡稱「本公司」）提供的各項 AI 數碼營銷、社交媒體管理及相關顧問服務。為保障雙方權益，請在簽署合作協議或使用本公司服務前，仔細閱讀以下免責聲明。當您開始使用本公司服務，即表示您已充分理解並同意以下條款：",
        sections: [
            {
                title: "1. 社交媒體平台政策與演算法風險",
                items: [
                    {
                        label: "平台規則變更：",
                        content: "本公司提供的 IG、Threads 等社交媒體帳號管理及增長服務，均遵循當下的平台演算法與最佳實踐進行有機自然增長（Organic Growth）。然而，第三方平台（如 Meta、WhatsApp 等）擁有隨時更改其演算法、使用條款及社群守則的絕對權利。"
                    },
                    {
                        label: "帳號限制：",
                        content: "若因第三方平台政策突變、系統故障，或客戶自身在帳號上發佈違反平台守則的內容，導致帳號遭遇限流、封鎖、停權或功能受限，本公司概不承擔任何直接或間接之賠償責任。"
                    },
                    {
                        label: "帳號轉讓風險：",
                        content: "針對「帳號買賣與啟動」服務，本公司保證交付時帳號的可用性與現有數據真實性。惟所有社交媒體帳號之最終擁有權及解釋權均屬該平台官方所有，客戶接手後的營運風險與帳號存續狀態，需由客戶自行承擔。"
                    }
                ]
            },
            {
                title: "2. 營銷成效與收益聲明",
                items: [
                    {
                        label: "非保證收益：",
                        content: "本公司致力於運用前沿 AI 技術為客戶優化曝光、增長真實粉絲及提升互動率。然而，所有關於流量增長、粉絲數量預估、潛在名單獲取（Lead Generation）或實際銷售轉化率的數據，均為基於過往經驗之「預測」與「目標」，不構成任何具法律約束力的業績或收益保證。"
                    },
                    {
                        label: "市場變數：",
                        content: "最終商業變現能力受多重不可控因素影響（如：客戶產品本身的市場競爭力、定價策略、宏觀經濟環境等），本公司不對客戶的最終營業額或利潤損失負責。"
                    }
                ]
            },
            {
                title: "3. AI 系統運作與內容產出",
                items: [
                    {
                        label: "AI 內容準確性：",
                        content: "本公司利用人工智能（包括但不限於文案生成、圖像合成、影片自動剪輯及 AI Chatbot 客服）協助生成內容。儘管系統經過優化與訓練，但 AI 仍可能產生不準確、不完整或存在語義偏差的內容（即「AI 幻覺」）。"
                    },
                    {
                        label: "客戶審核義務：",
                        content: "客戶有責任在內容正式發佈前進行最終審閱。若因 AI 客服系統（如 WhatsApp Chatbot）在自動回覆中出現資訊錯誤（包括但不限於報錯價格、時間或產品規格）而引發的消費者糾紛，本公司將協助修正系統邏輯，但對因此造成的商業損失不負財務賠償責任。"
                    },
                    {
                        label: "版權與二創：",
                        content: "本公司運用 AI 進行之內容策展與二次創作（Secondary Creation），旨在符合合理使用原則。惟知識產權法律規範隨科技發展不斷演進，客戶需自行評估並承擔發佈相關合成內容之潛在版權風險。本公司不對因內容版權爭議引起的任何索償負責。"
                    }
                ]
            },
            {
                title: "4. 線下活動與實體贈品 (O2O 營銷)",
                content: "對於結合「禮品與贈品 (Gift & Premium)」及線下活動的營銷專案，本公司負責線上系統（如 QR Code 導流、線上名單收集）的穩定運作。因線下活動現場突發狀況、場地網絡不穩、實體贈品瑕疵或物流延誤等非本公司直接控制因素導致的營銷中斷，本公司不承擔相關責任。"
            },
            {
                title: "5. 服務中斷與不可抗力因素",
                content: "如因天災、黑客攻擊、電信供應商故障、伺服器停機維護等不可抗力因素（Force Majeure）導致本公司 AI 系統、自動化客服或營銷服務中斷，本公司將盡力協助恢復運作，但不承擔服務中斷期間所衍生的任何損失。"
            }
        ]
    },
    admin: {
        loginTitle: "管理員登入",
        loginSubtitle: "輸入憑證以管理內容",
        passwordLabel: "密碼",
        loginBtn: "登入",
        hint: "這是 Artegize 員工的專用區域。",
        dashboardTitle: "管理儀表板",
        welcome: "歡迎",
        aiAssistant: "AI 內容助手",
        aiPlaceholder: "輸入主題 (例如：'AI 在 SEO 中的優勢')",
        generate: "生成",
        thinking: "思考中...",
        createPost: "建立新文章",
        postTitle: "標題",
        postCategory: "分類",
        postImage: "圖片",
        postExcerpt: "摘要",
        postContent: "完整內容",
        publish: "發布文章",
        manageContent: "管理內容",
        
        // New Account Management Translations
        tabPosts: "博客文章",
        tabAccounts: "IG 帳號",
        tabClients: "我們的客戶",
        createAccount: "上架新帳號",
        createClient: "新增客戶",
        clientName: "客戶名稱",
        clientLogo: "Logo",
        addClient: "新增客戶",
        accHandle: "帳號名稱",
        accNiche: "領域",
        accFollowers: "粉絲數",
        accEngagement: "互動率",
        accPrice: "價格",
        accDescription: "描述",
        publishAccount: "上架帳號"
    },
    diagrams: {
        growth: {
            title: "增長對比",
            subtitle: "傳統營銷 vs Artegize AI 策略",
            traditional: "傳統廣告公司",
            ai: "Artegize AI 增長"
        },
        process: {
            title: "Artegize 工作流程",
            step1: { title: "AI 策略", desc: "數據驅動分析與內容規劃" },
            step2: { title: "自動化執行", desc: "高頻率內容發布與互動" },
            step3: { title: "真實增長", desc: "真實粉絲與商業轉化" }
        },
        ecosystem: {
            title: "O2O 增長閉環",
            center: { title: "Artegize", subtitle: "AI 核心" },
            nodes: {
                online: "線上流量",
                fans: "忠實粉絲",
                offline: "線下活動",
                gifts: "實體禮品"
            },
            steps: [
                "1. AI 吸引線上流量",
                "2. 禮品推動線下互動",
                "3. 活動獲取真實名單",
                "4. 數據回饋至 AI"
            ]
        },
        igGrowth: {
            systemTitle: "自動引流系統",
            views: "數百萬 每月觀看",
            autoRun: "設定後系統自動運作",
            hours: "24小時",
            clients: "吸引精準客戶"
        },
        workshops: {
            title: "AI 精通之路",
            steps: [
                { title: "學習", desc: "掌握 AI 工具" },
                { title: "實踐", desc: "建立工作流" },
                { title: "增長", desc: "擴展業務" }
            ]
        },
        marketing: {
            title: "整合策略",
            core: "AI 大腦",
            channels: ["社交媒體", "付費廣告", "內容營銷", "數據分析"]
        },
        gift: {
            title: "數碼實體轉化",
            flow: ["實體禮品", "QR 掃碼", "線上追蹤", "數據獲取"]
        },
        event: {
            title: "活動回報閉環",
            flow: ["現場人流", "AI 互動", "名單獲取", "數位資產"]
        },
        accountSales: {
            title: "即時權威",
            steps: [
                { title: "零等待", desc: "跳過冷啟動期" },
                { title: "社會證明", desc: "即時獲得信任" },
                { title: "隨時變現", desc: "立即開始銷售" }
            ]
        }
    }
  }
};
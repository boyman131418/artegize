import React, { useEffect } from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

import IGGrowthDiagram from '../components/IGGrowthDiagram';
import WorkshopDiagram from '../components/WorkshopDiagram';
import GiftDiagram from '../components/GiftDiagram';

const ServiceDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { language, posts } = useApp();
  const t = TRANSLATIONS[language];
  
  // Find the service by slug
  const service = t.services.items.find(item => item.slug === slug);

  // Filter related posts
  const relatedPosts = posts.filter(post => post.serviceSlug === slug);

  // Scroll to top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!service) {
    return <Navigate to="/services" replace />;
  }

  // If it's account sales, redirect to the dedicated page
  if (service.slug === 'account-sales') {
    return <Navigate to="/account-sales" replace />;
  }

  const renderDiagram = () => {
    switch (service.slug) {
      case 'ig-account-management':
        return <IGGrowthDiagram />;
      case 'ai-workshops':
        return <WorkshopDiagram />;
      case 'gift-premium':
        return <GiftDiagram />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-brand-dark pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="mb-8 text-sm text-gray-400">
          <Link to="/" className="hover:text-brand-primary transition-colors">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/services" className="hover:text-brand-primary transition-colors">Services</Link>
          <span className="mx-2">/</span>
          <span className="text-white">{service.title}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start mb-20">
          {/* Left Column: Title and Icon */}
          <div className="space-y-8">
            <div className="w-20 h-20 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-2xl flex items-center justify-center shadow-lg shadow-brand-primary/20">
              <i className={`fas ${service.icon} text-white text-4xl`}></i>
            </div>
            
            <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-tight">
              {service.title}
            </h1>
            
            <div className="text-xl text-brand-primary font-medium italic border-l-4 border-brand-primary pl-6 py-2">
              {service.details?.quote}
            </div>

            <p className="text-lg text-gray-300 leading-relaxed">
              {service.description}
            </p>

            <div className="pt-8">
              <Link to="/contact" className="inline-flex items-center justify-center px-8 py-4 bg-white text-brand-dark font-bold rounded-full hover:bg-gray-200 transition-all shadow-lg hover:shadow-white/20">
                {t.services.cta} <i className="fas fa-arrow-right ml-2"></i>
              </Link>
            </div>
          </div>

          {/* Right Column: Detailed Content */}
          <div className="space-y-8">
            <div className="glass-panel p-8 rounded-2xl border border-white/10 space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                  <i className="fas fa-info-circle text-brand-secondary mr-3"></i>
                  Service Details
                </h3>
                <div className="text-gray-300 leading-relaxed whitespace-pre-line">
                  {service.details?.content}
                </div>
              </div>

              <div className="border-t border-white/10 pt-8">
                <h3 className="text-2xl font-bold text-white mb-4 flex items-center">
                  <i className="fas fa-gem text-brand-accent mr-3"></i>
                  Commercial Value
                </h3>
                <div className="text-gray-300 leading-relaxed">
                  {service.details?.value}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Diagram Section - Full Width */}
        <div className="mb-20 animate-fade-in-up">
          {renderDiagram()}
        </div>

        {/* Related Portfolio Section */}
        {relatedPosts.length > 0 && (
          <div className="border-t border-white/10 pt-16">
            <h2 className="text-3xl font-bold text-white mb-8">Related Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {relatedPosts.map(post => (
                <div key={post.id} className="glass-panel rounded-xl overflow-hidden border border-white/10 hover:border-brand-primary/50 transition-all group">
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={post.imageUrl} 
                      alt={post.title} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-semibold text-brand-primary uppercase tracking-wider">
                        {post.category}
                      </span>
                      <span className="text-xs text-gray-500">{post.date}</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-brand-primary transition-colors">
                      {post.link ? (
                        <a href={post.link} target="_blank" rel="noopener noreferrer">
                          {post.title}
                        </a>
                      ) : (
                        post.title
                      )}
                    </h3>
                    <p className="text-gray-400 text-sm line-clamp-3 mb-4">
                      {post.excerpt}
                    </p>
                    {post.link && (
                      <a href={post.link} target="_blank" rel="noopener noreferrer" className="text-brand-accent text-sm font-medium hover:text-white transition-colors flex items-center">
                        View Project <i className="fas fa-arrow-right ml-2 text-xs"></i>
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceDetail;

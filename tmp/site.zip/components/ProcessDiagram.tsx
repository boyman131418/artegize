import React from 'react';
import { Brain, Rocket, TrendingUp, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const ProcessDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.process || TRANSLATIONS['en'].diagrams?.process;

  return (
    <div className="w-full py-10">
      <h3 className="text-xl font-bold text-white mb-8 text-center">{t.title}</h3>
      <div className="flex flex-col md:flex-row items-center justify-center gap-6 relative">
        
        {/* Step 1 */}
        <div className="flex flex-col items-center text-center max-w-[200px] z-10">
          <div className="w-20 h-20 rounded-full bg-brand-primary/20 border border-brand-primary flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(99,102,241,0.3)]">
            <Brain className="w-10 h-10 text-brand-primary" />
          </div>
          <h4 className="text-lg font-bold text-white mb-2">{t.step1.title}</h4>
          <p className="text-sm text-gray-400">{t.step1.desc}</p>
        </div>

        {/* Arrow 1 */}
        <div className="hidden md:block text-gray-600">
          <ArrowRight className="w-8 h-8" />
        </div>
        <div className="md:hidden text-gray-600 my-2">
          <ArrowRight className="w-8 h-8 rotate-90" />
        </div>

        {/* Step 2 */}
        <div className="flex flex-col items-center text-center max-w-[200px] z-10">
          <div className="w-20 h-20 rounded-full bg-brand-secondary/20 border border-brand-secondary flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(168,85,247,0.3)]">
            <Rocket className="w-10 h-10 text-brand-secondary" />
          </div>
          <h4 className="text-lg font-bold text-white mb-2">{t.step2.title}</h4>
          <p className="text-sm text-gray-400">{t.step2.desc}</p>
        </div>

        {/* Arrow 2 */}
        <div className="hidden md:block text-gray-600">
          <ArrowRight className="w-8 h-8" />
        </div>
        <div className="md:hidden text-gray-600 my-2">
          <ArrowRight className="w-8 h-8 rotate-90" />
        </div>

        {/* Step 3 */}
        <div className="flex flex-col items-center text-center max-w-[200px] z-10">
          <div className="w-20 h-20 rounded-full bg-brand-accent/20 border border-brand-accent flex items-center justify-center mb-4 shadow-[0_0_20px_rgba(236,72,153,0.3)]">
            <TrendingUp className="w-10 h-10 text-brand-accent" />
          </div>
          <h4 className="text-lg font-bold text-white mb-2">{t.step3.title}</h4>
          <p className="text-sm text-gray-400">{t.step3.desc}</p>
        </div>

      </div>
    </div>
  );
};

export default ProcessDiagram;

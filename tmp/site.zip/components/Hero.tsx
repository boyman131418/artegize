import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { LOGO_URL } from '../constants';

const Hero: React.FC = () => {
  const { language, posts } = useApp();
  const t = TRANSLATIONS[language].hero;
  const [bgImage, setBgImage] = useState<string>('');

  useEffect(() => {
    if (posts.length > 0) {
      const randomIndex = Math.floor(Math.random() * posts.length);
      setBgImage(posts[randomIndex].imageUrl);
    }
  }, [posts]);

  return (
    <div className="relative overflow-hidden bg-brand-dark py-32 sm:py-40 lg:py-48 min-h-[70vh] flex items-center justify-center">
      {/* Background Image with Overlay */}
      {bgImage && (
        <>
          <div 
            className="absolute inset-0 z-0 bg-cover bg-center transition-opacity duration-1000"
            style={{ backgroundImage: `url(${bgImage})` }}
          ></div>
          <div className="absolute inset-0 z-0 bg-black/80"></div> {/* Dark Overlay */}
        </>
      )}

      {/* Abstract Background Shapes */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full z-0 pointer-events-none opacity-40">
         <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-primary/20 rounded-full blur-3xl opacity-50 mix-blend-screen animate-pulse"></div>
         <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-brand-secondary/20 rounded-full blur-3xl opacity-50 mix-blend-screen"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="flex justify-center mb-8">
          <img 
            src={LOGO_URL} 
            alt="Artegize Logo" 
            className="h-16 sm:h-24 md:h-32 w-auto max-w-[90%] object-contain drop-shadow-2xl" 
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
            }}
          />
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white mb-8 drop-shadow-lg leading-tight">
          <span className="block">{t.title1}</span>
          <span className="block text-transparent bg-clip-text bg-gradient-to-r from-brand-primary via-brand-secondary to-brand-accent pb-2">
            {t.title2}
          </span>
        </h1>
        <p className="mt-6 text-xl text-gray-200 max-w-3xl mx-auto mb-10 drop-shadow-md">
          {t.description}
        </p>
        <div className="flex justify-center gap-4">
          <a href="#services" className="px-8 py-3 bg-brand-primary hover:bg-indigo-600 text-white font-bold rounded-full transition-all shadow-[0_0_20px_rgba(99,102,241,0.5)]">
            {t.cta_explore}
          </a>
          <a href="#contact" className="px-8 py-3 border border-white/40 hover:bg-white/10 text-white font-bold rounded-full transition-all backdrop-blur-sm">
            {t.cta_quote}
          </a>
        </div>
      </div>
    </div>
  );
};

export default Hero;
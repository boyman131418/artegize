import React from 'react';
import Hero from '../components/Hero';
import ServiceCard from '../components/ServiceCard';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import SEO from '../components/SEO';
import { Users, Monitor, Award, Clock } from 'lucide-react';

const Home: React.FC = () => {
  const { posts, language } = useApp();
  const t = TRANSLATIONS[language];

  return (
    <div className="flex flex-col min-h-screen">
      <SEO 
        title={language === 'en' ? 'Home' : '首頁'} 
        description={language === 'en' ? 'Transform your marketing with AI.' : '用 AI 轉型您的營銷。'} 
      />
      <Hero />
      
      {/* Stats Section */}
      <section className="py-20 relative overflow-hidden border-y border-white/5">
        {/* Background Gradient/Glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-brand-dark via-brand-primary/5 to-brand-dark opacity-50 pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            
            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all hover:-translate-y-1 group hover:border-brand-primary/30 hover:shadow-[0_0_30px_rgba(99,102,241,0.15)]">
              <div className="w-14 h-14 mx-auto mb-4 bg-brand-primary/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Users className="w-7 h-7 text-brand-primary" />
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold text-white mb-2 tracking-tight">200+</div>
              <div className="text-xs sm:text-sm font-bold text-brand-primary uppercase tracking-widest opacity-80">{t.stats.accounts}</div>
            </div>

            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all hover:-translate-y-1 group hover:border-brand-secondary/30 hover:shadow-[0_0_30px_rgba(168,85,247,0.15)]">
              <div className="w-14 h-14 mx-auto mb-4 bg-brand-secondary/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Monitor className="w-7 h-7 text-brand-secondary" />
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold text-white mb-2 tracking-tight">50+</div>
              <div className="text-xs sm:text-sm font-bold text-brand-secondary uppercase tracking-widest opacity-80">{t.stats.workshops}</div>
            </div>

            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all hover:-translate-y-1 group hover:border-brand-accent/30 hover:shadow-[0_0_30px_rgba(236,72,153,0.15)]">
              <div className="w-14 h-14 mx-auto mb-4 bg-brand-accent/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Award className="w-7 h-7 text-brand-accent" />
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold text-white mb-2 tracking-tight">100%</div>
              <div className="text-xs sm:text-sm font-bold text-brand-accent uppercase tracking-widest opacity-80">{t.stats.satisfaction}</div>
            </div>

            <div className="p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all hover:-translate-y-1 group hover:border-blue-500/30 hover:shadow-[0_0_30px_rgba(59,130,246,0.15)]">
              <div className="w-14 h-14 mx-auto mb-4 bg-blue-500/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Clock className="w-7 h-7 text-blue-500" />
              </div>
              <div className="text-4xl sm:text-5xl font-extrabold text-white mb-2 tracking-tight">24/7</div>
              <div className="text-xs sm:text-sm font-bold text-blue-400 uppercase tracking-widest opacity-80">{t.stats.monitoring}</div>
            </div>

          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-brand-dark">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white">{t.services.title}</h2>
            <p className="mt-4 text-gray-400">{t.services.subtitle}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {t.services.items.map(service => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section className="py-20 bg-white/5 border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-white">{t.whyUs.title}</h2>
            <p className="mt-4 text-gray-400 max-w-3xl mx-auto">{t.whyUs.subtitle}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {t.whyUs.items.map((item, index) => (
              <div key={index} className="bg-brand-dark p-8 rounded-2xl border border-white/10 hover:border-brand-primary/50 transition-all group">
                <div className="w-14 h-14 bg-brand-primary/20 rounded-xl flex items-center justify-center mb-6 group-hover:bg-brand-primary/30 transition-colors">
                  <i className={`fas ${item.icon} text-brand-primary text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold text-white mb-4">{item.title}</h3>
                <div className="text-gray-400 leading-relaxed text-sm">
                   {/* Handle bold text parsing simply by replacing ** with bold tags or just rendering as is if we don't have a parser. 
                       Since we don't have a markdown parser handy in this context without adding deps or complexity, 
                       we'll just render the text. If bolding is crucial, we can use a simple split. 
                   */}
                   {item.description.split('**').map((part, i) => 
                      i % 2 === 1 ? <strong key={i} className="text-white">{part}</strong> : part
                   )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Updates / Blog */}
      <section id="portfolio" className="py-20 bg-gradient-to-b from-brand-dark to-black/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-10">{t.portfolio.title}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map(post => (
              <div key={post.id} className="bg-brand-dark rounded-xl overflow-hidden border border-white/10 hover:border-brand-primary/50 transition-all shadow-lg">
                <div className="h-48 overflow-hidden">
                  <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 hover:scale-110" />
                </div>
                <div className="p-6">
                  <span className="text-xs font-semibold text-brand-accent uppercase tracking-wider">{post.category}</span>
                  <h3 className="mt-2 text-xl font-bold text-white leading-tight">
                    {post.link ? (
                      <a href={post.link} target="_blank" rel="noopener noreferrer" className="hover:text-brand-primary transition-colors">
                        {post.title}
                      </a>
                    ) : (
                      post.title
                    )}
                  </h3>
                  <p className="mt-3 text-gray-400 text-sm line-clamp-3">{post.excerpt}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-xs text-gray-500">{post.date}</span>
                    {post.link && (
                      <a href={post.link} target="_blank" rel="noopener noreferrer" className="text-brand-primary text-sm font-medium hover:text-brand-accent">
                        View Project &rarr;
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-brand-dark">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass-panel p-10 rounded-2xl border border-white/10">
            <h2 className="text-3xl font-bold text-white mb-6">{t.contact.title}</h2>
            <p className="text-gray-400 mb-8">
              {t.contact.description}
            </p>
            <form className="space-y-4 text-left">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" placeholder={t.contact.namePlaceholder} className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary" />
                <input type="email" placeholder={t.contact.emailPlaceholder} className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary" />
              </div>
              <textarea rows={4} placeholder={t.contact.msgPlaceholder} className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary"></textarea>
              <button type="submit" className="w-full bg-gradient-to-r from-brand-primary to-brand-secondary text-white font-bold py-3 rounded-lg hover:opacity-90 transition">
                {t.contact.submit}
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
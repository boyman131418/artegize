import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import AccountSalesDiagram from '../components/AccountSalesDiagram';

const AccountSales: React.FC = () => {
  const { accounts, language } = useApp();
  const t = TRANSLATIONS[language].accountSales;

  return (
    <div className="min-h-screen bg-brand-dark pt-10 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-secondary to-brand-accent">
              {t.title}
            </span>
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
            {t.subtitle}
          </p>
        </div>

        {/* Value Proposition Diagram */}
        <div className="animate-fade-in-up delay-200">
          <AccountSalesDiagram />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {accounts.map(account => (
            <div key={account.id} className="bg-brand-dark rounded-xl overflow-hidden border border-white/10 hover:border-brand-secondary/50 transition-all shadow-lg hover:shadow-brand-secondary/20 flex flex-col h-full">
              {/* Account Header Image */}
              <div className="h-40 overflow-hidden relative">
                <img src={account.imageUrl} alt={account.niche} className="w-full h-full object-cover blur-[2px]" />
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <i className="fab fa-instagram text-4xl text-white"></i>
                </div>
                <div className="absolute top-3 right-3 bg-green-500/80 text-white text-xs px-2 py-1 rounded-full backdrop-blur-md">
                    <i className="fas fa-check-circle mr-1"></i> {t.verified}
                </div>
              </div>
              
              <div className="p-6 flex-grow flex flex-col">
                <div className="flex justify-between items-start mb-4">
                    <div>
                        <h3 className="text-xl font-bold text-white tracking-wide">{account.handle}</h3>
                        <span className="text-xs text-brand-secondary font-semibold uppercase tracking-wider border border-brand-secondary/30 px-2 py-0.5 rounded mt-1 inline-block">
                            {account.niche}
                        </span>
                    </div>
                </div>

                <p className="text-gray-400 text-sm mb-6 flex-grow">
                    {account.description}
                </p>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-4 mb-6 bg-white/5 p-4 rounded-lg">
                    <div className="text-center">
                        <div className="text-gray-500 text-xs mb-1">{t.followers}</div>
                        <div className="text-white font-bold text-lg">{account.followers}</div>
                    </div>
                    <div className="text-center border-l border-white/10">
                        <div className="text-gray-500 text-xs mb-1">{t.engagement}</div>
                        <div className="text-brand-accent font-bold text-lg">{account.engagement}</div>
                    </div>
                </div>

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/10">
                    <div>
                        <div className="text-gray-500 text-xs">{t.price}</div>
                        <div className="text-2xl font-bold text-white">{account.price}</div>
                    </div>
                    <a 
                        href={`https://wa.me/85296997127?text=I'm interested in the account ${account.handle}`} 
                        target="_blank" 
                        rel="noreferrer"
                        className="bg-brand-secondary hover:bg-purple-600 text-white px-5 py-2.5 rounded-lg font-medium transition-colors flex items-center"
                    >
                        {t.inquire} <i className="fas fa-arrow-right ml-2 text-xs"></i>
                    </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AccountSales;
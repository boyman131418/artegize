import { BlogPost, IGAccount } from './types';

export const LOGO_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAg8AAABrCAYAAADw32HHAAAACXBIWXMAAC4jAAAuIwF4pT92AAAaxUlEQVR4nO2d63XbRhOGn+Tkv5gKDFcgpgIjFZipwEgFoSswXEHkCgJVELkCgxWEqiBgBR9Zgb8fww0oihcssDeA85zDI1siF0tgL+/Ozsz+8P37dxImAxb71xy4O/GeHVADT/vXNlDdFEVRFOUm+SFR8ZADJfDO8nM7REAsURGhKIpyTLZ/AazRcVLpSYri4QH4Y2AZO0R8PAyujaIoyvjI969s/7q0ENsgQqIGKlRQKB1ITTzU2FsbLrFCtjy0MyiKMmXmyFiXM3wMfUStt8oVUhIPFfDBQ7nPQIEoa0VRlKkwQ8a2JfDGcdk7RIjouKmcJBXxkAPfPJavHUFRlKkwQwTDktNO5K7YIRaNxuM1lJGSinhYA/eer6EdQVGUsVMgvlw+RcMhX5HtEEV5QQriYQ78E+haz4gFQvfyFEUZGxV+tnav8TM6ZipH/Bi7AoiSDsU9EsqpKIoyJiriCAeQBZ6ivOCn2BVALAEheYeEcZaBr6ukj3FAm114T4VufSlhWRJPOCjKSVLYtohVgV+R0FBFARGTXRzQdlwWF4rimi3hfBxO8QvqbK4cEXvbIot47QqdBBQxya6BT3QboO8Iby1TbpecuMJhhwoH5QS3LB7eIAJCuU1miNf6P/iP9FGUsaJZepWTxBYPsXmPriJvkRxZTQ1Ng64oU2aDigflDLcuHkC3L26JGRJt8w33GfkUxQexQiR3aGp/5QIqHmQSWcauhOKdAomSeB+3GopixRqxAITE5MNRXwflLLHFQxb5+oZPpFMXxS0ZElXzF3EdzxSlLyG3Dr6gwkHpgIqHlip2BRTnlMgg6PKkVkUJzQOSJtonj8Bb9DRNpSMqHlreoc6TU8E2/FJRUmeBTPAueQY+IumnCzT5mWKBioeXVLEroAxCwy+VKVMgye1WPT+/QrYlfkMEwxzpL2ppUKyJnWEyenrLE/yOiogxskAGwhBRFJqdVHFFhoiCNXbn7mSIpTRDRMBhxFi9/7ndl9ugVgXFMTHFQ8jTNG3YkJ5FRDnPDBF7IaMofkMPWFOGUyJbawY9/loZDTG3LfKI177EG8Ke9Kn0Z0mc8Ms88PWUaTFDrAOfjn7/Hj2wTxkJMS0PT6Qbc6/Wh7TJEGtDrCiKHa1wsaXp+TkfzDh93PIa3Qf3xQJpu+ccead68NoM6TP5/v8NIqBq0ukPYyQ/8bsg/TemeIh9Utw1pur7kNNOGucmjyf6xZYv9uXlJ/7WIAPFE8MadsnrFdvY2CD3KlQs/Qx5JubZZHTzDdnQPrf1/ueYRYVp8xmnFwfGRwDc+7TkSNvtInhD+tSYe5LzejzYIuPA0LrM92VcEkxr2knPXK9BhQW0zyXHrv8e3tcax/03lnhYAH/HuLAFY7c+ZEiDs50wDF/onnmzRLZ6upb/uP9MY1GfHBnIphJF8Yjf7bEM6WcFbu/ZV0QADhWBvsloB9s5/e7B4eDb8HKC68KM9hnYWMk+4j4x1OEENEfuT9d7MuRI7hxpKy4WikbMhqZBJt4q4DVnSLtZ4NbC+ox8jycG3stY4uGBcRxKNCbrQ0Y7WOYMjzroYj6dI/en7+TUZZCcIUJjDO3FhhV+fCcK7CervvQRgT6Z0w64PqNujlfKzf51bNHr+ww+M9z34XDhkDPsftgsJI7rUJO2hdmGvvfBhnx/jRBb+o/I+F33+XAs8dAwjoOJUrc+mMEyx8+K/NKKw9XAcGkFHjL8MjSuxUOBTDgx7tUj8TITmhXakum0kz6LFmPlyHGzeDikT1udIWPHVJ6JYYgV5hI53be1XLOiR5KwGNEWvlcFLkkx8sI4Hq2RUNc/8GfKP2d5cLmi+MDpgdKEYI6lrcQiR9rCX8S7Vx+Qgcf3quwQY5FqgD+ZVjtpOr7PCKcn4H9IG/hAGveiJI16uMZ1KG2GjKXfiOcA/g74F0trVyzxMCbK2BXYczxYhtj7z0/8LsO9KfIDr9vF3PE1psYMscp8Iw0/kDukXT7hP1qgRPrBFNOP77huRs4QYd0ggiG1qLWc6W0z+qBEJu1Uzt75hCxEsi5vDi0ejGltTKRgfViQzmDpyvnpmAemGaLmgznSyVMcoN8jk9+pKJ6hmO+dQj/wxdOFv2XIvf0XEdyp3gPXzp4p4WLLIqNtx6lxj9Ttav8NLR4WpNvgL1FGvHaFRKbEuG/Z0f8r/K1y3zA+YRmDAplAUjYJ3+NeQCy5jTNLygu/T2mVeo4F035G9cDPGwGc8j26Q/pacelNocXDkD3RFeLAGINY1ocHZIURiwWtNWAZoC4h98zHSIGYqccgwO9wJyAqZEtk6jzy2t/BOB6muEo9xZT78CPDnIILZFIeQ/8FGWuKc38MKR6GxFr/QpurwPWxtF0pA18vJ75Z+o42vj3E4H1P2tEtLmks318gnXlMGAExZDuqwo9o3SChwr/uX78Rb2yBNmvpMRVpr1IPyUjfMjKEIdsxBePrvyDf+eQC4KeAleirSAte7jMV+5+hV+TG+lAFul4qCv6OsIPXnHTyBvjEZu+0wN/As6Kd4HPcP+shFogKP/38XHjwE21GxdCrwwWvV7U56TlDXiKVMcsHX+nv77DAX/99pnVSHpJb5Bym/2Yctc9QlocZ/QaBFacdiArkpoWmDHgtHw5nY8B87zWyGpsiJstbF3wNPF+An2njy5fIvX+LDJQuucd+1VbgRzh85fIW5Bq5JyHb3kdO76XnAevggjx2BTzSVxiZRHquWSF9dU7bf3OkT39xfK07TszDoSwPfW98eaXMbz3L7UtI68OtRx5saZPemKx9hjWtCjax7qFXijapcre0q5aG7qmdfQ08l5IQNbSHN7mcvP9Avnfd4b0Zfjz2d3TzXVojY0+IrbpHphGdMGM82yu2fKGfNXSGn+i0S4n1trR5gFwuOt7ty/2vrYbKMLnF/gZ2yWr2RHizXqiskzXT3j88x1fsoy4eCOsf0qeOffDhlW2TYrfGfV79LhY1X/3a9jyRBr9RLdfux4I0zgDqMhbnDFvMGfP7IRnxI/R2nDDZd8RHO7YZeyrcLgBe3IsQ2xYF/R5+1eE9MfbYQkVeVAGukSJ99hWHeED34VIsvitK3AuHDXZ9pnR8/Xuu950MfwsC2+fm+znnHa4fY3u2D3nPzz0jDvHG/H74KpD24HobzYYH+o0vC9y343NOtecoHV//7vD6IcRD2fNzXTpug/v9nS6UAa5RIQfkTHXff8w0nsvP8BOaZ2ser3EfHl0O/PsQasv3Vx7qcEiXSalgPALClkfavAfn2BJvW2dDv/Y4w0/becJu7GkQq5FLluy3kH2Lh5x+Zr+vdFd7IeEn2FDWhxKZSH4nXo6L0DSxK5AAvgbLPivpxnEdriUD87kdZLuC9O2022ULZ71/30fPdQnNM93H0MxfNS7S17K9xM9WS5/+Wzuuwx375+ZbPJQ9P1dZvDeWMi0CXWeL3I+MuHHooahjVyAyOf7M9k2Pz9SO6wDn+86c9BLo9A3P64KNU/QDMgZ89lOVoOywE4mFp3pc4lyk3zVm+NtO99kWbViCX/HQN+Z0g/1DeyC8Kn9H+NCkAvdmqJRYoZaHInYFjsg8lPme0+NniuHJqQzYIAuJErFEpobNfXqgez/PieM4Xvb8nC+rQ0q8AeY+xUNf9dVH7cWyPpQRrllFuGYoqtgViEyG3+RntpPzDH8C+VS5madrDSG0M24XKtJbRNQd32frR2DzXlc80t/iVrirxivyQJ/pVK4v8ZDRfxDsKwJuxfoQwtM/BjaJk6aK7/DPiu4TdLZ/v69QxRhWhinlTqljV+CILd2c1wuLMheEtzrs6C9YFvgN7X2g+3xjnDZ93b/cV5KosufnnulvtjbWh9AHyJSEFRBbRL2HOlXxkTb74AP+EsEUnsodE4Xn8u+RkxmvJbjK8N++cs/ln2KO/aTrc9uiHvjZ1A7LKrmc4vx3un/nGXGsyTZbKsf4Fv93SC6Na/03RMKuuQ/xMKP/TawGXrsifIcy1oc64DUbwogHE1e8Rb5fvv/umh+7/7mP";

export const INITIAL_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'The Future of AI in Marketing',
    excerpt: 'How generative AI is reshaping the landscape of digital engagement and content creation.',
    content: 'Artificial Intelligence is no longer just a buzzword; it is the engine driving modern marketing strategies. At Artegize, we leverage cutting-edge LLMs to analyze consumer behavior and generate hyper-personalized content at scale...',
    imageUrl: 'https://picsum.photos/800/600?random=1',
    date: '2023-10-15',
    category: 'Industry Insights'
  },
  {
    id: '2',
    title: 'Managing 200+ IG Accounts Efficiently',
    excerpt: 'Strategies for scaling social media presence without losing the human touch.',
    content: 'Scaling social media operations requires a blend of automation and authentic engagement. Our team manages over 200 Instagram accounts using a proprietary blend of AI scheduling tools and human oversight...',
    imageUrl: 'https://picsum.photos/800/600?random=2',
    date: '2023-11-02',
    category: 'Case Study'
  },
  {
    id: '3',
    title: 'Upcoming AI Workshop: Master the Tools',
    excerpt: 'Join our face-to-face workshop in Hong Kong this weekend.',
    content: 'Ready to take your marketing skills to the next level? Join our hands-on workshop where we dive deep into prompt engineering, visual generation, and automated analytics. Limited seats available.',
    imageUrl: 'https://picsum.photos/800/600?random=3',
    date: '2023-11-20',
    category: 'Events'
  }
];

export const INITIAL_ACCOUNTS: IGAccount[] = [
  {
    id: '1',
    handle: '@lux_travel_***',
    niche: 'Travel & Luxury',
    followers: '45.2k',
    engagement: '5.8%',
    price: '$1,200 USD',
    imageUrl: 'https://picsum.photos/400/400?random=10',
    description: 'High engagement travel page focusing on luxury destinations. Audience mainly from USA and Europe.'
  },
  {
    id: '2',
    handle: '@fit_life_***',
    niche: 'Health & Fitness',
    followers: '28.5k',
    engagement: '4.2%',
    price: '$850 USD',
    imageUrl: 'https://picsum.photos/400/400?random=11',
    description: 'Established fitness community. Great for supplement brands or coaching services.'
  },
  {
    id: '3',
    handle: '@tech_gadgets_***',
    niche: 'Tech & Gadgets',
    followers: '12.1k',
    engagement: '6.5%',
    price: '$450 USD',
    imageUrl: 'https://picsum.photos/400/400?random=12',
    description: 'Fast growing tech review page. High viral potential on Reels.'
  },
  {
    id: '4',
    handle: '@pet_lovers_***',
    niche: 'Pets',
    followers: '85k',
    engagement: '3.9%',
    price: '$2,500 USD',
    imageUrl: 'https://picsum.photos/400/400?random=13',
    description: 'Viral cat and dog content. Very active comment section.'
  },
  {
    id: '5',
    handle: '@fashion_daily_***',
    niche: 'Fashion',
    followers: '32k',
    engagement: '4.8%',
    price: '$950 USD',
    imageUrl: 'https://picsum.photos/400/400?random=14',
    description: 'Streetwear and modern fashion aesthetics. Perfect for clothing brands.'
  },
  {
    id: '6',
    handle: '@crypto_news_***',
    niche: 'Finance & Crypto',
    followers: '18k',
    engagement: '7.2%',
    price: '$1,500 USD',
    imageUrl: 'https://picsum.photos/400/400?random=15',
    description: 'High net worth audience interested in investment and crypto.'
  }
];

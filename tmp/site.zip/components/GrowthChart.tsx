import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const data = [
  { month: 'M1', traditional: 100, ai: 100 },
  { month: 'M2', traditional: 120, ai: 150 },
  { month: 'M3', traditional: 140, ai: 250 },
  { month: 'M4', traditional: 160, ai: 400 },
  { month: 'M5', traditional: 180, ai: 650 },
  { month: 'M6', traditional: 200, ai: 1000 },
];

const GrowthChart: React.FC = () => {
  const { language } = useApp();
  // Fallback to 'en' if diagrams translation is missing (though we just added it)
  const t = TRANSLATIONS[language].diagrams?.growth || TRANSLATIONS['en'].diagrams?.growth;

  return (
    <div className="w-full h-[400px] bg-black/20 p-6 rounded-xl border border-white/10">
      <h3 className="text-xl font-bold text-white mb-2 text-center">{t.title}</h3>
      <p className="text-sm text-gray-400 mb-6 text-center">{t.subtitle}</p>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
          <XAxis dataKey="month" stroke="#9ca3af" />
          <YAxis stroke="#9ca3af" />
          <Tooltip 
            contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
            itemStyle={{ color: '#e5e7eb' }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="traditional" 
            name={t.traditional} 
            stroke="#9ca3af" 
            strokeWidth={2} 
            dot={{ r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="ai" 
            name={t.ai} 
            stroke="#6366f1" 
            strokeWidth={3} 
            dot={{ r: 6, fill: '#6366f1' }} 
            activeDot={{ r: 8 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default GrowthChart;

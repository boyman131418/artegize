import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateMarketingCopy = async (topic: string, tone: string = 'professional'): Promise<string> => {
  if (!apiKey) {
    console.warn("API Key is missing. Returning mock data.");
    return "AI generation is unavailable (Missing API Key). Please configure your environment.";
  }

  try {
    const prompt = `
      You are an expert marketing copywriter for "Artegize".
      Write a compelling blog post excerpt and a short introductory paragraph about: "${topic}".
      The tone should be ${tone}.
      Focus on how AI can enhance this specific aspect of marketing.
      Keep it under 150 words total.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "No content generated.";
  } catch (error) {
    console.error("Error generating content:", error);
    return "Failed to generate content. Please try again later.";
  }
};
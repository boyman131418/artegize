import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const AdminLogin: React.FC = () => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, language } = useApp();
  const navigate = useNavigate();
  const t = TRANSLATIONS[language].admin;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(password)) {
      navigate('/admin');
    } else {
      setError('Invalid password. Hint: admin123');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-dark px-4">
      <div className="glass-panel p-8 rounded-2xl w-full max-w-md border border-white/10 shadow-2xl">
        <div className="text-center mb-8">
          <i className="fas fa-user-shield text-4xl text-brand-primary mb-4"></i>
          <h2 className="text-2xl font-bold text-white">{t.loginTitle}</h2>
          <p className="text-gray-400 text-sm mt-2">{t.loginSubtitle}</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{t.passwordLabel}</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none transition"
              placeholder=""
            />
          </div>
          
          {error && <p className="text-red-400 text-sm">{error}</p>}
          
          <button
            type="submit"
            className="w-full bg-brand-primary hover:bg-indigo-600 text-white font-bold py-3 rounded-lg transition duration-200"
          >
            {t.loginBtn}
          </button>
        </form>
        
        <div className="mt-6 text-center text-xs text-gray-500">
          <p>{t.hint}</p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
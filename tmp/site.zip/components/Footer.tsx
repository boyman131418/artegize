import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Link } from 'react-router-dom';
import { LOGO_URL } from '../constants';

const Footer: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language];
  const footerT = t.footer;

  return (
    <footer className="bg-black/90 border-t border-white/10 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand Column */}
          <div>
            <Link to="/" className="inline-block">
              <img 
                src={LOGO_URL} 
                alt="Artegize Logo" 
                className="h-8 sm:h-10 w-auto max-w-[150px] sm:max-w-[200px] object-contain" 
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  (e.target as HTMLImageElement).parentElement!.innerHTML = '<span class="text-2xl font-bold text-white bg-clip-text text-transparent bg-gradient-to-r from-brand-primary to-brand-accent">Artegize</span>';
                }}
              />
            </Link>
            <p className="text-gray-400 mt-4 text-sm leading-relaxed">
              {footerT.tagline}
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-primary hover:text-white transition-all">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-secondary hover:text-white transition-all">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-accent hover:text-white transition-all">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>

          {/* Services Column */}
          <div>
            <h3 className="text-white font-bold mb-6">{footerT.sections?.services}</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><Link to="/services/ai-workshops" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.workshops}</Link></li>
              <li><Link to="/services/ig-account-management" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.management}</Link></li>
              <li><Link to="/account-sales" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.trading}</Link></li>
              <li><Link to="/services/marketing-solutions" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.marketing}</Link></li>
              <li><Link to="/services/gift-premium" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.gift}</Link></li>
              <li><Link to="/services/offline-event-marketing" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.events}</Link></li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h3 className="text-white font-bold mb-6">{footerT.sections?.company}</h3>
            <ul className="space-y-3 text-sm text-gray-400">
              <li><Link to="/about" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.about}</Link></li>
              <li><Link to="/clients" className="hover:text-brand-primary transition-colors">{t.nav.clients}</Link></li>
              <li><Link to="/portfolio" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.portfolio}</Link></li>
              <li><Link to="/contact" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.contact}</Link></li>
              <li><Link to="/disclaimer" className="hover:text-brand-primary transition-colors">{footerT.sections?.links.disclaimer}</Link></li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-white font-bold mb-6">{footerT.sections?.contact}</h3>
            <ul className="space-y-4 text-sm text-gray-400">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-brand-primary"></i>
                <span>{t.contact.address}</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-3 text-brand-primary"></i>
                <a href={`mailto:${t.contact.email}`} className="hover:text-white transition-colors">{t.contact.email}</a>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone mr-3 text-brand-primary"></i>
                <a href={`tel:${t.contact.phone}`} className="hover:text-white transition-colors">{t.contact.phone}</a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 text-center text-gray-600 text-sm">
          &copy; {new Date().getFullYear()} {footerT.rights}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
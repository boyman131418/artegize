import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import GrowthChart from '../components/GrowthChart';
import ProcessDiagram from '../components/ProcessDiagram';

const About: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].about;

  // Helper to render text with bold markers **
  const renderText = (text: string) => {
    return text.split('**').map((part, i) => 
      i % 2 === 1 ? <strong key={i} className="text-brand-primary">{part}</strong> : part
    );
  };

  return (
    <div className="min-h-screen bg-brand-dark pt-20 pb-20">
      <SEO 
        title={t.title} 
        description={t.subtitle} 
      />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white mb-4 leading-tight">
            {t.title}
          </h1>
          <p className="text-xl text-brand-primary font-serif italic">
            {t.subtitle}
          </p>
        </div>

        {/* Process Diagram Section */}
        <div className="mb-16">
           <ProcessDiagram />
        </div>

        {/* Origin Section */}
        <div className="mb-16 glass-panel p-8 rounded-2xl border border-white/10">
          <h2 className="text-2xl font-bold text-white mb-6 border-l-4 border-brand-primary pl-4">
            {t.origin.title}
          </h2>
          <div className="text-gray-300 leading-relaxed space-y-4">
            {t.origin.content.split('\n').map((paragraph, idx) => (
              <p key={idx}>{renderText(paragraph)}</p>
            ))}
          </div>
        </div>

        {/* Growth Chart Section */}
        <div className="mb-32">
           <GrowthChart />
        </div>

        {/* Who We Are Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-6 border-l-4 border-brand-secondary pl-4">
            {t.whoWeAre.title}
          </h2>
          <div className="text-gray-300 leading-relaxed space-y-4">
             {t.whoWeAre.content.split('\n').map((paragraph, idx) => (
              <p key={idx}>{renderText(paragraph)}</p>
            ))}
          </div>
        </div>

        {/* Philosophy Section */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">
            {t.philosophy.title}
          </h2>
          <div className="grid gap-8">
            {t.philosophy.items.map((item, index) => (
              <div key={index} className="bg-white/5 p-6 rounded-xl border border-white/10 hover:border-brand-primary/30 transition-all">
                <h3 className="text-xl font-bold text-brand-accent mb-3">
                  {index + 1}. {item.title}
                </h3>
                <p className="text-gray-300 leading-relaxed">
                  {renderText(item.description)}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Mission Section */}
        <div className="text-center bg-gradient-to-r from-brand-primary/20 to-brand-secondary/20 p-10 rounded-3xl border border-white/10">
          <h2 className="text-2xl font-bold text-white mb-6">
            {t.mission.title}
          </h2>
          <p className="text-xl text-white font-medium italic leading-relaxed">
            {t.mission.content}
          </p>
          <div className="mt-8">
            <Link to="/contact" className="inline-block px-8 py-3 bg-brand-primary hover:bg-brand-primary/80 text-white rounded-full font-bold transition-all shadow-lg shadow-brand-primary/25">
              {TRANSLATIONS[language].services.cta}
            </Link>
          </div>
        </div>

      </div>
    </div>
  );
};

export default About;

import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import SEO from '../components/SEO';

const Portfolio: React.FC = () => {
  const { posts, language } = useApp();
  const t = TRANSLATIONS[language].portfolio;

  return (
    <div className="min-h-screen bg-brand-dark pt-10 pb-20">
      <SEO 
        title={t.title} 
        description={t.subtitle} 
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            {t.title}
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
            {t.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map(post => (
            <div key={post.id} className="group bg-brand-dark rounded-xl overflow-hidden border border-white/10 hover:border-brand-primary/50 transition-all shadow-lg hover:shadow-brand-primary/20">
              <div className="h-56 overflow-hidden relative">
                <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60"></div>
                <span className="absolute bottom-4 left-4 text-xs font-bold text-white bg-brand-primary/80 px-2 py-1 rounded backdrop-blur-sm">
                    {post.category}
                </span>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-white leading-tight mb-3 group-hover:text-brand-primary transition-colors">
                  {post.link ? (
                    <a href={post.link} target="_blank" rel="noopener noreferrer" className="hover:underline">
                      {post.title}
                    </a>
                  ) : (
                    post.title
                  )}
                </h3>
                <p className="text-gray-400 text-sm line-clamp-3 mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between border-t border-white/10 pt-4">
                  <span className="text-xs text-gray-500">{post.date}</span>
                  {post.link && (
                    <a href={post.link} target="_blank" rel="noopener noreferrer" className="text-brand-accent text-sm font-medium hover:text-white transition-colors">
                      View Project &rarr;
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Portfolio;
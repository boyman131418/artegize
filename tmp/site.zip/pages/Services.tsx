import React from 'react';
import ServiceCard from '../components/ServiceCard';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Link } from 'react-router-dom';
import SEO from '../components/SEO';
import EcosystemDiagram from '../components/EcosystemDiagram';

const Services: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].services;

  return (
    <div className="min-h-screen bg-brand-dark pt-10 pb-20">
      <SEO 
        title={t.title} 
        description={t.subtitle} 
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-accent">
              {t.title}
            </span>
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
            {t.subtitle}
          </p>
        </div>

        {/* Ecosystem Diagram */}
        <div className="mb-20 max-w-4xl mx-auto">
            <EcosystemDiagram />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {t.items.map((service, index) => (
            <div key={service.id} className="h-full">
               <ServiceCard service={service} />
            </div>
          ))}
        </div>

        {/* Additional "Why Choose Us" block could go here */}
        
        <div className="text-center mt-12">
            <div className="inline-block p-[2px] rounded-full bg-gradient-to-r from-brand-primary to-brand-secondary">
                <Link to="/contact" className="block px-8 py-3 bg-brand-dark rounded-full text-white font-bold hover:bg-white/10 transition-all">
                    {t.cta}
                </Link>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const AdminDashboard: React.FC = () => {
  const { posts, addPost, deletePost, accounts, addAccount, deleteAccount, clients, addClient, deleteClient, user, language } = useApp();
  const t = TRANSLATIONS[language].admin;
  const servicesT = TRANSLATIONS[language].services;
  
  const [activeTab, setActiveTab] = useState<'posts' | 'accounts' | 'clients'>('posts');

  // Post Form State
  const [postTitle, setPostTitle] = useState('');
  const [postCategory, setPostCategory] = useState('General');
  const [postServiceSlug, setPostServiceSlug] = useState('');
  const [postLink, setPostLink] = useState('');
  const [postContent, setPostContent] = useState('');
  const [postExcerpt, setPostExcerpt] = useState('');
  const [postImageUrl, setPostImageUrl] = useState('https://picsum.photos/800/600');
  
  // Account Form State
  const [accHandle, setAccHandle] = useState('');
  const [accNiche, setAccNiche] = useState('');
  const [accFollowers, setAccFollowers] = useState('');
  const [accEngagement, setAccEngagement] = useState('');
  const [accPrice, setAccPrice] = useState('');
  const [accImageUrl, setAccImageUrl] = useState('https://picsum.photos/400/400');
  const [accDescription, setAccDescription] = useState('');

  // Client Form State
  const [clientName, setClientName] = useState('');
  const [clientImageUrl, setClientImageUrl] = useState('https://picsum.photos/200/200');

  const [uploadStatus, setUploadStatus] = useState('');

  // Handle Image Upload (Convert to Base64 for persistence)
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'post' | 'account' | 'client') => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (limit to ~500KB to avoid filling localStorage too fast)
      if (file.size > 500000) {
        setUploadStatus('Error: Image too large. Please use an image under 500KB.');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        if (type === 'post') setPostImageUrl(base64String);
        else if (type === 'account') setAccImageUrl(base64String);
        else setClientImageUrl(base64String);
        setUploadStatus('Image uploaded & converted for saving.');
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePostSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (postTitle && postExcerpt) {
      addPost({
        title: postTitle,
        category: postCategory,
        serviceSlug: postServiceSlug,
        link: postLink,
        content: postContent,
        excerpt: postExcerpt,
        imageUrl: postImageUrl
      });
      // Reset form
      setPostTitle('');
      setPostCategory('General');
      setPostServiceSlug('');
      setPostLink('');
      setPostContent('');
      setPostExcerpt('');
      setUploadStatus('Post published!');
      setTimeout(() => setUploadStatus(''), 3000);
    }
  };

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accHandle && accPrice) {
        addAccount({
            handle: accHandle,
            niche: accNiche,
            followers: accFollowers,
            engagement: accEngagement,
            price: accPrice,
            description: accDescription,
            imageUrl: accImageUrl
        });
        // Reset
        setAccHandle('');
        setAccNiche('');
        setAccFollowers('');
        setAccEngagement('');
        setAccPrice('');
        setAccDescription('');
        setUploadStatus('Account listed!');
        setTimeout(() => setUploadStatus(''), 3000);
    }
  };

  const handleClientSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (clientName) {
      addClient({
        name: clientName,
        imageUrl: clientImageUrl
      });
      setClientName('');
      setClientImageUrl('https://picsum.photos/200/200');
      setUploadStatus('Client added!');
      setTimeout(() => setUploadStatus(''), 3000);
    }
  };

  if (!user.isAuthenticated) {
    return <div className="text-center text-white py-20">Access Denied. Please login.</div>;
  }

  return (
    <div className="min-h-screen bg-brand-dark pb-20 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">{t.dashboardTitle}</h1>
          <div className="text-gray-400 text-sm">{t.welcome}, {user.username}</div>
        </div>

        {/* Tabs */}
        <div className="flex space-x-4 mb-8 border-b border-white/10 pb-1">
            <button 
                onClick={() => setActiveTab('posts')}
                className={`px-4 py-2 font-medium text-sm transition-colors relative ${activeTab === 'posts' ? 'text-brand-primary' : 'text-gray-400 hover:text-white'}`}
            >
                {t.tabPosts}
                {activeTab === 'posts' && <div className="absolute bottom-[-5px] left-0 w-full h-0.5 bg-brand-primary"></div>}
            </button>
            <button 
                onClick={() => setActiveTab('accounts')}
                className={`px-4 py-2 font-medium text-sm transition-colors relative ${activeTab === 'accounts' ? 'text-brand-primary' : 'text-gray-400 hover:text-white'}`}
            >
                {t.tabAccounts}
                {activeTab === 'accounts' && <div className="absolute bottom-[-5px] left-0 w-full h-0.5 bg-brand-primary"></div>}
            </button>
            <button 
                onClick={() => setActiveTab('clients')}
                className={`px-4 py-2 font-medium text-sm transition-colors relative ${activeTab === 'clients' ? 'text-brand-primary' : 'text-gray-400 hover:text-white'}`}
            >
                {t.tabClients}
                {activeTab === 'clients' && <div className="absolute bottom-[-5px] left-0 w-full h-0.5 bg-brand-primary"></div>}
            </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Editor Column */}
          <div className="lg:col-span-2 space-y-8">
            <div className="glass-panel p-6 rounded-xl border border-white/10">
              
              {activeTab === 'posts' ? (
                /* --- POST FORM --- */
                <form onSubmit={handlePostSubmit} className="space-y-4">
                  <h2 className="text-xl font-bold text-white mb-6">{t.createPost}</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">{t.postTitle}</label>
                      <input
                        type="text"
                        value={postTitle}
                        onChange={(e) => setPostTitle(e.target.value)}
                        className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">{t.postCategory}</label>
                      <select
                        value={postCategory}
                        onChange={(e) => setPostCategory(e.target.value)}
                        className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white mb-4"
                      >
                        <option>General</option>
                        <option>Case Study</option>
                        <option>Industry Insights</option>
                        <option>Events</option>
                      </select>

                      <label className="block text-sm text-gray-400 mb-1">Related Service</label>
                      <select
                        value={postServiceSlug}
                        onChange={(e) => setPostServiceSlug(e.target.value)}
                        className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white mb-4"
                      >
                        <option value="">None</option>
                        {servicesT?.items?.map((service: any) => (
                          <option key={service.id} value={service.slug}>
                            {service.title}
                          </option>
                        ))}
                      </select>

                      <label className="block text-sm text-gray-400 mb-1">External Project Link (Optional)</label>
                      <input
                        type="url"
                        value={postLink}
                        onChange={(e) => setPostLink(e.target.value)}
                        className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                        placeholder="https://example.com/project"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400 mb-1">{t.postImage}</label>
                    <div className="flex items-center space-x-4">
                      <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, 'post')}
                          className="text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-indigo-600"
                      />
                      {postImageUrl && <img src={postImageUrl} alt="Preview" className="h-10 w-10 rounded object-cover border border-white/20" />}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400 mb-1">{t.postExcerpt}</label>
                    <textarea
                      value={postExcerpt}
                      onChange={(e) => setPostExcerpt(e.target.value)}
                      rows={2}
                      className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                      required
                    ></textarea>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400 mb-1">{t.postContent}</label>
                    <textarea
                      value={postContent}
                      onChange={(e) => setPostContent(e.target.value)}
                      rows={6}
                      className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                    ></textarea>
                  </div>

                  {uploadStatus && <p className="text-green-400 text-sm">{uploadStatus}</p>}

                  <div className="pt-4">
                    <button type="submit" className="w-full bg-brand-primary hover:bg-indigo-600 text-white font-bold py-3 rounded-lg transition">
                      {t.publish}
                    </button>
                  </div>
                </form>
              ) : activeTab === 'accounts' ? (
                /* --- ACCOUNT FORM --- */
                <form onSubmit={handleAccountSubmit} className="space-y-4">
                    <h2 className="text-xl font-bold text-white mb-6">{t.createAccount}</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.accHandle}</label>
                            <input
                                type="text"
                                value={accHandle}
                                onChange={(e) => setAccHandle(e.target.value)}
                                className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                                placeholder="@username_***"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.accNiche}</label>
                            <input
                                type="text"
                                value={accNiche}
                                onChange={(e) => setAccNiche(e.target.value)}
                                className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                                placeholder="Travel, Fitness, etc."
                            />
                        </div>
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.accFollowers}</label>
                            <input
                                type="text"
                                value={accFollowers}
                                onChange={(e) => setAccFollowers(e.target.value)}
                                className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                            />
                        </div>
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.accEngagement}</label>
                            <input
                                type="text"
                                value={accEngagement}
                                onChange={(e) => setAccEngagement(e.target.value)}
                                className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                            />
                        </div>
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.accPrice}</label>
                            <input
                                type="text"
                                value={accPrice}
                                onChange={(e) => setAccPrice(e.target.value)}
                                className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm text-gray-400 mb-1">{t.postImage}</label>
                            <div className="flex items-center space-x-4">
                                <input
                                    type="file"
                                    accept="image/*"
                                    onChange={(e) => handleImageUpload(e, 'account')}
                                    className="text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-indigo-600"
                                />
                                {accImageUrl && <img src={accImageUrl} alt="Preview" className="h-10 w-10 rounded object-cover border border-white/20" />}
                            </div>
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm text-gray-400 mb-1">{t.accDescription}</label>
                        <textarea
                            value={accDescription}
                            onChange={(e) => setAccDescription(e.target.value)}
                            rows={3}
                            className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                        ></textarea>
                    </div>

                    {uploadStatus && <p className="text-green-400 text-sm">{uploadStatus}</p>}

                    <div className="pt-4">
                        <button type="submit" className="w-full bg-brand-secondary hover:bg-purple-600 text-white font-bold py-3 rounded-lg transition">
                            {t.publishAccount}
                        </button>
                    </div>
                </form>
              ) : (
                /* --- CLIENT FORM --- */
                <form onSubmit={handleClientSubmit} className="space-y-4">
                  <h2 className="text-xl font-bold text-white mb-6">{t.createClient}</h2>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">{t.clientName}</label>
                      <input
                        type="text"
                        value={clientName}
                        onChange={(e) => setClientName(e.target.value)}
                        className="w-full bg-black/40 border border-white/20 rounded-lg px-4 py-2 text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm text-gray-400 mb-1">{t.clientLogo}</label>
                      <div className="flex items-center space-x-4">
                        <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleImageUpload(e, 'client')}
                            className="text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-brand-primary file:text-white hover:file:bg-indigo-600"
                        />
                        {clientImageUrl && <img src={clientImageUrl} alt="Preview" className="h-10 w-10 rounded object-contain border border-white/20 bg-white" />}
                      </div>
                    </div>
                  </div>

                  {uploadStatus && <p className="text-green-400 text-sm">{uploadStatus}</p>}

                  <div className="pt-4">
                    <button type="submit" className="w-full bg-brand-accent hover:bg-pink-600 text-white font-bold py-3 rounded-lg transition">
                      {t.addClient}
                    </button>
                  </div>
                </form>
              )}

            </div>
          </div>

          {/* List Column */}
          <div className="lg:col-span-1">
            <div className="glass-panel p-6 rounded-xl border border-white/10 h-full">
              <h2 className="text-xl font-bold text-white mb-6">{t.manageContent}</h2>
              <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                
                {activeTab === 'posts' ? (
                    // POSTS LIST
                    posts.map(post => (
                    <div key={post.id} className="bg-black/30 p-4 rounded-lg border border-white/5 hover:border-brand-primary/30 transition">
                        <div className="flex justify-between items-start mb-2">
                            <span className="text-xs text-brand-accent font-semibold">{post.category}</span>
                            <button onClick={() => deletePost(post.id)} className="text-gray-500 hover:text-red-400 transition">
                                <i className="fas fa-trash-alt"></i>
                            </button>
                        </div>
                        <h3 className="text-white font-medium text-sm mb-1">{post.title}</h3>
                        <p className="text-gray-500 text-xs truncate">{post.excerpt}</p>
                        <div className="mt-2 text-xs text-gray-600">{post.date}</div>
                    </div>
                    ))
                ) : activeTab === 'accounts' ? (
                    // ACCOUNTS LIST
                    accounts.map(acc => (
                        <div key={acc.id} className="bg-black/30 p-4 rounded-lg border border-white/5 hover:border-brand-secondary/30 transition">
                            <div className="flex justify-between items-start mb-2">
                                <span className="text-xs text-brand-secondary font-semibold">{acc.niche}</span>
                                <button onClick={() => deleteAccount(acc.id)} className="text-gray-500 hover:text-red-400 transition">
                                    <i className="fas fa-trash-alt"></i>
                                </button>
                            </div>
                            <h3 className="text-white font-medium text-sm mb-1">{acc.handle}</h3>
                            <div className="flex justify-between text-xs text-gray-500 mt-2">
                                <span>{acc.followers}</span>
                                <span className="text-white">{acc.price}</span>
                            </div>
                        </div>
                    ))
                ) : (
                    // CLIENTS LIST
                    clients.map(client => (
                      <div key={client.id} className="bg-black/30 p-4 rounded-lg border border-white/5 hover:border-brand-accent/30 transition flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <img src={client.imageUrl} alt={client.name} className="w-10 h-10 rounded object-contain bg-white" />
                          <h3 className="text-white font-medium text-sm">{client.name}</h3>
                        </div>
                        <button onClick={() => deleteClient(client.id)} className="text-gray-500 hover:text-red-400 transition">
                            <i className="fas fa-trash-alt"></i>
                        </button>
                      </div>
                    ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
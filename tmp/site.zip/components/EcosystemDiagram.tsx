import React from 'react';
import { Store, Globe, Users, Gift, RefreshCw, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const EcosystemDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.ecosystem || TRANSLATIONS['en'].diagrams?.ecosystem;

  return (
    <div className="w-full bg-gradient-to-br from-brand-dark to-black p-8 rounded-2xl border border-white/10 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      
      <h3 className="text-2xl font-bold text-white mb-10 text-center relative z-10">{t.title}</h3>
      
      {/* New Grid Layout - Cleaner and more robust */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Step 1: Online */}
        <div className="bg-white/5 p-6 rounded-xl border border-white/10 flex flex-col items-center text-center relative group hover:border-blue-500/50 transition-all">
          <div className="w-16 h-16 rounded-xl bg-blue-500/20 border border-blue-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Globe className="text-blue-400 w-8 h-8" />
          </div>
          <h4 className="text-white font-bold mb-2">{t.nodes.online}</h4>
          <p className="text-xs text-gray-400">{t.steps[0]}</p>
          
          {/* Arrow for desktop */}
          <div className="hidden lg:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-20 text-gray-600">
             <ArrowRight className="w-6 h-6" />
          </div>
          {/* Arrow for mobile/tablet */}
          <div className="lg:hidden absolute -bottom-3 left-1/2 transform -translate-x-1/2 z-20 text-gray-600 rotate-90">
             <ArrowRight className="w-6 h-6" />
          </div>
        </div>

        {/* Step 2: Gifts */}
        <div className="bg-white/5 p-6 rounded-xl border border-white/10 flex flex-col items-center text-center relative group hover:border-purple-500/50 transition-all">
          <div className="w-16 h-16 rounded-xl bg-purple-500/20 border border-purple-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Gift className="text-purple-400 w-8 h-8" />
          </div>
          <h4 className="text-white font-bold mb-2">{t.nodes.gifts}</h4>
          <p className="text-xs text-gray-400">{t.steps[1]}</p>

          {/* Arrow for desktop */}
          <div className="hidden lg:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-20 text-gray-600">
             <ArrowRight className="w-6 h-6" />
          </div>
          {/* Arrow for mobile/tablet */}
          <div className="lg:hidden absolute -bottom-3 left-1/2 transform -translate-x-1/2 z-20 text-gray-600 rotate-90">
             <ArrowRight className="w-6 h-6" />
          </div>
        </div>

        {/* Step 3: Offline */}
        <div className="bg-white/5 p-6 rounded-xl border border-white/10 flex flex-col items-center text-center relative group hover:border-orange-500/50 transition-all">
          <div className="w-16 h-16 rounded-xl bg-orange-500/20 border border-orange-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Store className="text-orange-400 w-8 h-8" />
          </div>
          <h4 className="text-white font-bold mb-2">{t.nodes.offline}</h4>
          <p className="text-xs text-gray-400">{t.steps[2]}</p>

          {/* Arrow for desktop */}
          <div className="hidden lg:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-20 text-gray-600">
             <ArrowRight className="w-6 h-6" />
          </div>
          {/* Arrow for mobile/tablet */}
          <div className="lg:hidden absolute -bottom-3 left-1/2 transform -translate-x-1/2 z-20 text-gray-600 rotate-90">
             <ArrowRight className="w-6 h-6" />
          </div>
        </div>

        {/* Step 4: Fans/Data */}
        <div className="bg-white/5 p-6 rounded-xl border border-white/10 flex flex-col items-center text-center relative group hover:border-green-500/50 transition-all">
          <div className="w-16 h-16 rounded-xl bg-green-500/20 border border-green-500 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <Users className="text-green-400 w-8 h-8" />
          </div>
          <h4 className="text-white font-bold mb-2">{t.nodes.fans}</h4>
          <p className="text-xs text-gray-400">{t.steps[3]}</p>
        </div>

      </div>

      {/* Central Core (Visual only) */}
      <div className="mt-12 flex justify-center">
        <div className="flex items-center gap-3 bg-brand-primary/10 border border-brand-primary/30 px-6 py-3 rounded-full">
            <RefreshCw className="w-5 h-5 text-brand-primary animate-spin-slow" />
            <span className="text-brand-primary font-bold">{t.center.title} - {t.center.subtitle}</span>
        </div>
      </div>

    </div>
  );
};

export default EcosystemDiagram;

import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';

const Disclaimer: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].disclaimer;

  return (
    <div className="min-h-screen bg-brand-dark pt-24 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-panel p-8 md:p-12 rounded-2xl border border-white/10">
          <h1 className="text-3xl font-bold text-white mb-8 border-b border-white/10 pb-4">
            {t.title}
          </h1>
          
          <div className="space-y-8 text-gray-300 leading-relaxed">
            <p>
              {t.intro}
            </p>

            {t.sections.map((section, index) => (
              <section key={index}>
                <h2 className="text-xl font-bold text-brand-primary mb-3">{section.title}</h2>
                {section.items ? (
                  <ul className="list-disc pl-5 space-y-2">
                    {section.items.map((item, i) => (
                      <li key={i}>
                        <strong className="text-white">{item.label}</strong> {item.content}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>{section.content}</p>
                )}
              </section>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Disclaimer;

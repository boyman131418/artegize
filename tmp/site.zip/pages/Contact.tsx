import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import SEO from '../components/SEO';

const Contact: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].contact;

  return (
    <div className="min-h-screen bg-brand-dark pt-10 pb-20 relative overflow-hidden">
        <SEO 
          title={t.title} 
          description={t.subtitle} 
        />
        {/* Decorative background */}
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-accent/10 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-brand-primary/10 rounded-full blur-3xl opacity-30 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            {t.title}
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
            {t.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div className="flex flex-col h-full space-y-8">
                <div className="glass-panel p-8 rounded-2xl border border-white/10">
                    <h3 className="text-2xl font-bold text-white mb-6">{t.infoTitle}</h3>
                    <div className="space-y-6">
                        <div className="flex items-start space-x-4">
                            <div className="w-10 h-10 bg-brand-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                                <i className="fas fa-envelope text-brand-primary"></i>
                            </div>
                            <div>
                                <p className="text-sm text-gray-400">Email</p>
                                <p className="text-white font-medium">{t.email}</p>
                            </div>
                        </div>
                        <div className="flex items-start space-x-4">
                            <div className="w-10 h-10 bg-brand-secondary/20 rounded-full flex items-center justify-center flex-shrink-0">
                                <i className="fas fa-phone text-brand-secondary"></i>
                            </div>
                            <div>
                                <p className="text-sm text-gray-400">WhatsApp / Phone</p>
                                <a href="https://wa.me/85296997127" target="_blank" rel="noopener noreferrer" className="text-white font-medium hover:text-brand-secondary transition-colors">{t.phone}</a>
                            </div>
                        </div>
                        <div className="flex items-start space-x-4">
                            <div className="w-10 h-10 bg-brand-accent/20 rounded-full flex items-center justify-center flex-shrink-0">
                                <i className="fas fa-map-marker-alt text-brand-accent"></i>
                            </div>
                            <div>
                                <p className="text-sm text-gray-400">Address</p>
                                <a href="https://maps.app.goo.gl/8QcCY6L4EK3n5iB56" target="_blank" rel="noopener noreferrer" className="text-white font-medium hover:text-brand-accent transition-colors">{t.address}</a>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="glass-panel p-8 rounded-2xl border border-white/10 text-center mt-auto">
                    <p className="text-gray-300 mb-4">Connect with us on social media</p>
                    <div className="flex justify-center space-x-6">
                        <a href="#" className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-brand-primary hover:text-white transition-all">
                            <i className="fab fa-instagram text-xl"></i>
                        </a>
                        <a href="#" className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-blue-600 hover:text-white transition-all">
                            <i className="fab fa-facebook-f text-xl"></i>
                        </a>
                        <a href="#" className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:bg-blue-700 hover:text-white transition-all">
                            <i className="fab fa-linkedin-in text-xl"></i>
                        </a>
                    </div>
                </div>
            </div>

            {/* Contact Form */}
            <div className="glass-panel p-10 rounded-2xl border border-white/10 shadow-2xl">
                <form className="space-y-6">
                <div>
                    <label className="block text-sm text-gray-400 mb-2">{t.namePlaceholder}</label>
                    <input type="text" className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition" placeholder="" />
                </div>
                <div>
                    <label className="block text-sm text-gray-400 mb-2">{t.emailPlaceholder}</label>
                    <input type="email" className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition" placeholder="" />
                </div>
                <div>
                    <label className="block text-sm text-gray-400 mb-2">{t.msgPlaceholder}</label>
                    <textarea rows={5} className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-brand-primary focus:ring-1 focus:ring-brand-primary transition" placeholder=""></textarea>
                </div>
                <button type="submit" className="w-full bg-gradient-to-r from-brand-primary to-brand-secondary text-white font-bold py-4 rounded-lg hover:shadow-lg hover:shadow-brand-primary/25 hover:scale-[1.02] transition-all">
                    {t.submit}
                </button>
                </form>
            </div>
        </div>

        {/* Map Section */}
        <div className="mt-20 rounded-2xl overflow-hidden border border-white/10 shadow-2xl h-[400px] relative">
            <iframe 
                width="100%" 
                height="100%" 
                frameBorder="0" 
                scrolling="no" 
                marginHeight={0} 
                marginWidth={0} 
                src="https://maps.google.com/maps?q=The+Bayview,+633+Castle+Peak+Road,+Tsuen+Wan,+Hong+Kong&t=&z=15&ie=UTF8&iwloc=&output=embed"
                style={{ filter: 'grayscale(100%) invert(92%) contrast(83%)' }}
                title="Artegize Location"
            ></iframe>
            <div className="absolute inset-0 pointer-events-none border-4 border-brand-dark/20 rounded-2xl"></div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
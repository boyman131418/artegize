import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Gift, QrCode, UserPlus, Database, Package, ArrowRight } from 'lucide-react';

const GiftDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.gift || TRANSLATIONS['en'].diagrams?.gift;

  const icons = [Gift, QrCode, UserPlus, Database];

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-16 relative overflow-hidden">
        
        {/* Background Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-lg bg-brand-primary/20 blur-[100px] rounded-full pointer-events-none"></div>

        {/* Floating Icons */}
        <div className="absolute bottom-10 left-10 animate-float-delayed opacity-40 hidden md:block">
          <Package className="text-pink-500" size={24} />
        </div>

        <div className="relative z-10">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-16 text-white tracking-wide uppercase">
            {t?.title}
          </h3>
          
          {/* Simplified Horizontal Flow */}
          <div className="relative max-w-5xl mx-auto">
            
            {/* Connecting Line Background */}
            <div className="absolute top-12 left-0 w-full h-1 bg-white/10 rounded-full hidden md:block"></div>
            <div className="absolute top-12 left-0 w-full h-1 bg-gradient-to-r from-yellow-400 via-red-500 to-purple-600 rounded-full hidden md:block opacity-50"></div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-4">
              {t?.flow.map((step: string, index: number) => {
                const Icon = icons[index];
                return (
                  <div key={index} className="flex flex-col items-center relative group">
                    
                    {/* Icon Circle */}
                    <div className="w-24 h-24 bg-brand-dark border-4 border-brand-dark rounded-full flex items-center justify-center z-10 shadow-xl relative transition-transform duration-300 group-hover:scale-110">
                      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-white/10 to-transparent"></div>
                      <div className={`absolute inset-0 rounded-full border-2 ${index === 0 ? 'border-yellow-400' : index === 1 ? 'border-orange-500' : index === 2 ? 'border-red-500' : 'border-purple-600'} opacity-100`}></div>
                      <Icon size={36} className="text-white relative z-10" />
                    </div>

                    {/* Step Number */}
                    <div className="absolute top-0 right-1/2 translate-x-10 -translate-y-2 bg-brand-accent text-white text-xs font-bold px-2 py-1 rounded-full border border-brand-dark z-20">
                      {index + 1}
                    </div>

                    {/* Text Content */}
                    <div className="mt-6 text-center">
                      <h4 className="text-lg font-bold text-white mb-2">{step}</h4>
                      {index < t.flow.length - 1 && (
                        <div className="md:hidden text-gray-500 my-2">
                          <ArrowRight size={20} />
                        </div>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>
          </div>

          {/* Bottom Label */}
          <div className="text-center mt-12">
            <p className="text-gray-400 text-sm italic">
              {language === 'en' ? 'Seamlessly bridging the physical and digital worlds' : '無縫連接實體與數碼世界'}
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

export default GiftDiagram;

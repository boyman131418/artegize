import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { LOGO_URL } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout, language, setLanguage } = useApp();
  const location = useLocation();
  const t = TRANSLATIONS[language].nav;

  const isActive = (path: string) => location.pathname === path ? 'text-brand-primary' : 'text-gray-300 hover:text-white';

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'zh' : 'en');
  };

  return (
    <nav className="sticky top-0 z-50 bg-brand-dark/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <img 
                src={LOGO_URL} 
                alt="Artegize Logo" 
                className="h-8 sm:h-10 w-auto max-w-[150px] sm:max-w-[200px] object-contain" 
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                  (e.target as HTMLImageElement).parentElement!.innerHTML = '<span class="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-primary to-brand-accent">Artegize</span>';
                }}
              />
            </Link>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              <Link to="/" className={`${isActive('/')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.home}</Link>
              <Link to="/about" className={`${isActive('/about')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.about}</Link>
              <Link to="/clients" className={`${isActive('/clients')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.clients}</Link>
              <Link to="/services" className={`${isActive('/services')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.services}</Link>
              <Link to="/account-sales" className={`${isActive('/account-sales')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.accountSales}</Link>
              <Link to="/portfolio" className={`${isActive('/portfolio')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.portfolio}</Link>
              <Link to="/contact" className={`${isActive('/contact')} px-3 py-2 rounded-md text-sm font-medium transition-colors`}>{t.contact}</Link>
              
              {user.isAuthenticated ? (
                <div className="flex items-center space-x-4 ml-4">
                  <Link to="/admin" className={`${isActive('/admin')} px-3 py-2 rounded-md text-sm font-medium`}>{t.dashboard}</Link>
                  <button onClick={logout} className="bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-1 rounded hover:bg-red-500/20 transition">{t.logout}</button>
                </div>
              ) : (
                <Link to="/login" className="text-gray-400 hover:text-white ml-4"><i className="fas fa-lock text-xs"></i></Link>
              )}

              <button 
                onClick={toggleLanguage} 
                className="ml-4 px-3 py-1 rounded border border-white/20 text-xs text-white hover:bg-white/10 transition"
              >
                {language === 'en' ? '中文' : 'EN'}
              </button>
            </div>
          </div>

          <div className="-mr-2 flex md:hidden items-center">
             <button 
                onClick={toggleLanguage} 
                className="mr-4 px-2 py-1 rounded border border-white/20 text-xs text-white hover:bg-white/10 transition"
              >
                {language === 'en' ? '中' : 'EN'}
              </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
            >
              <i className={`fas ${isOpen ? 'fa-times' : 'fa-bars'}`}></i>
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-brand-dark border-b border-white/10">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link to="/" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.home}</Link>
            <Link to="/about" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.about}</Link>
            <Link to="/clients" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.clients}</Link>
            <Link to="/services" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.services}</Link>
            <Link to="/account-sales" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.accountSales}</Link>
            <Link to="/portfolio" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.portfolio}</Link>
            <Link to="/contact" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.contact}</Link>
            {user.isAuthenticated ? (
              <>
                <Link to="/admin" className="text-brand-primary block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.dashboard}</Link>
                <button onClick={() => { logout(); setIsOpen(false); }} className="text-red-400 block px-3 py-2 rounded-md text-base font-medium w-full text-left">{t.logout}</button>
              </>
            ) : (
              <Link to="/login" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium" onClick={() => setIsOpen(false)}>{t.login}</Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
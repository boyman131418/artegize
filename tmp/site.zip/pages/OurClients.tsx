import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import SEO from '../components/SEO';

const OurClients: React.FC = () => {
  const { language, clients } = useApp();
  const t = TRANSLATIONS[language];

  return (
    <div className="min-h-screen bg-brand-dark pt-20 pb-20">
      <SEO 
        title={t.nav.clients} 
        description={language === 'en' ? 'Our valued clients and partners.' : '我們尊貴的客戶與合作夥伴。'} 
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in-up">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-6">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-primary to-brand-accent">
              {t.nav.clients}
            </span>
          </h1>
          <p className="mt-4 text-xl text-gray-400 max-w-3xl mx-auto">
            {language === 'en' ? 'Trusted by innovative brands and businesses.' : '深受創新品牌和企業的信賴。'}
          </p>
        </div>

        {clients.length === 0 ? (
          <div className="text-center py-20 bg-white/5 rounded-2xl border border-white/10">
            <p className="text-gray-400 text-lg">
              {language === 'en' ? 'No clients listed yet.' : '暫無客戶列表。'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
            {clients.map((client) => (
              <div 
                key={client.id} 
                className="bg-white p-8 rounded-xl flex items-center justify-center hover:shadow-[0_0_30px_rgba(255,255,255,0.1)] transition-all duration-300 group"
              >
                <img 
                  src={client.imageUrl} 
                  alt={client.name} 
                  className="max-w-full max-h-24 object-contain filter grayscale group-hover:grayscale-0 transition-all duration-300"
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default OurClients;

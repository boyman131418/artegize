import React from 'react';
import { Service } from '../types';
import { Link } from 'react-router-dom';

interface ServiceCardProps {
  service: Service;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const linkTo = service.slug === 'account-sales' ? '/account-sales' : `/services/${service.slug}`;

  return (
    <Link to={linkTo} className="block h-full">
      <div className="group relative p-8 glass-panel rounded-2xl hover:bg-white/10 transition-all duration-300 border border-white/5 h-full overflow-hidden min-h-[300px] hover:scale-105 hover:z-10 cursor-pointer">
        <div className="relative h-full">
          {/* Summary Content */}
          <div className="flex flex-col h-full transition-opacity duration-300 group-hover:opacity-0">
            <div className="w-12 h-12 bg-gradient-to-br from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center mb-6 shrink-0">
              <i className={`fas ${service.icon} text-white text-xl`}></i>
            </div>
            <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
            <p className="text-gray-400 mb-4">
              {service.description}
            </p>
          </div>

          {/* Hover Details */}
          {service.details && (
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10 overflow-y-auto scrollbar-thin scrollbar-thumb-brand-primary/50 scrollbar-track-transparent">
               <div className="min-h-full p-8 flex flex-col justify-center">
                 <div className="text-brand-primary font-bold italic mb-4 text-base">
                   {service.details.quote}
                 </div>
                 <div className="space-y-4 text-sm text-gray-200">
                   <p>{service.details.content}</p>
                   <p className="text-white font-medium">{service.details.value}</p>
                 </div>
                 <div className="mt-4 text-brand-accent text-sm font-bold flex items-center">
                    Click to learn more <i className="fas fa-arrow-right ml-2"></i>
                 </div>
               </div>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};

export default ServiceCard;

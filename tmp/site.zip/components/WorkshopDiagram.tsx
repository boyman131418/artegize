import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { BookOpen, Settings, TrendingUp, ArrowRight, Star, Zap, Award } from 'lucide-react';

const WorkshopDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.workshops || TRANSLATIONS['en'].diagrams?.workshops;

  const steps = [
    { icon: BookOpen, color: "text-white", bg: "bg-gradient-to-br from-blue-500 to-cyan-400" },
    { icon: Settings, color: "text-white", bg: "bg-gradient-to-br from-purple-500 to-pink-500" },
    { icon: TrendingUp, color: "text-white", bg: "bg-gradient-to-br from-green-500 to-emerald-400" }
  ];

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-12 relative overflow-hidden">
        
        {/* Background Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-lg bg-brand-primary/20 blur-[100px] rounded-full pointer-events-none"></div>

        {/* Floating Icons */}
        <div className="absolute top-10 left-10 animate-float-slow opacity-40 hidden md:block">
          <Star className="text-yellow-400" size={24} />
        </div>
        <div className="absolute bottom-10 right-10 animate-pulse-slow opacity-40 hidden md:block">
          <Zap className="text-brand-accent" size={24} />
        </div>

        <div className="relative z-10">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-12 text-white tracking-wide uppercase">
            {t?.title}
          </h3>
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 relative max-w-4xl mx-auto">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-10 left-0 w-full h-1 bg-white/10 -z-10"></div>

            {t?.steps.map((step: any, index: number) => {
              const Icon = steps[index].icon;
              return (
                <div key={index} className="flex flex-col items-center text-center z-10 w-full md:w-1/3 group">
                  <div className={`w-20 h-20 ${steps[index].bg} rounded-2xl flex items-center justify-center mb-6 shadow-lg transform group-hover:scale-110 transition-transform duration-300 relative`}>
                    <div className="absolute inset-0 bg-white/20 rounded-2xl blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    <Icon size={36} className={steps[index].color} />
                  </div>
                  <h4 className="text-xl font-bold text-white mb-2">{step.title}</h4>
                  <p className="text-gray-400 text-sm max-w-[200px]">{step.desc}</p>
                  
                  {index < 2 && (
                    <div className="md:hidden mt-6 text-white/20">
                      <ArrowRight size={24} className="transform rotate-90" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkshopDiagram;

import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Users, Bot, FileCheck, Coins, RefreshCw, Ticket, ArrowRight } from 'lucide-react';

const EventDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.event || TRANSLATIONS['en'].diagrams?.event;

  const icons = [Users, Bot, FileCheck, Coins];

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-12 relative overflow-hidden">
        
        {/* Background Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-lg bg-brand-primary/20 blur-[100px] rounded-full pointer-events-none"></div>

        {/* Floating Icons */}
        <div className="absolute top-10 right-10 animate-float-slow opacity-40 hidden md:block">
          <Ticket className="text-yellow-400" size={24} />
        </div>

        <div className="relative z-10">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-16 text-white tracking-wide uppercase">
            {t?.title}
          </h3>
          
          <div className="relative h-[400px] flex items-center justify-center max-w-4xl mx-auto">
            
            {/* The Loop Path (SVG) */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 400 400">
              <defs>
                <linearGradient id="loopGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FBBF24" />
                  <stop offset="50%" stopColor="#EF4444" />
                  <stop offset="100%" stopColor="#8B5CF6" />
                </linearGradient>
              </defs>
              <circle cx="200" cy="200" r="140" fill="none" stroke="url(#loopGradient)" strokeWidth="2" strokeDasharray="10 10" className="animate-spin-slow origin-center" />
            </svg>

            {/* Steps positioned on the circle */}
            {t?.flow.map((step: string, index: number) => {
              const Icon = icons[index];
              // 4 steps at 0, 90, 180, 270 degrees
              // Adjust angle to start from top (270deg or -90deg)
              // index 0: Top, 1: Right, 2: Bottom, 3: Left
              const positions = [
                'top-0 left-1/2 -translate-x-1/2', // Top
                'top-1/2 right-0 translate-x-1/2 -translate-y-1/2', // Right
                'bottom-0 left-1/2 -translate-x-1/2', // Bottom
                'top-1/2 left-0 -translate-x-1/2 -translate-y-1/2', // Left
              ];
              
              return (
                <div 
                  key={index} 
                  className={`absolute ${positions[index]} flex flex-col items-center group`}
                  style={{ 
                    // Manual offsets for circle layout if needed, but absolute positioning with transforms works well for 4 points
                  }}
                >
                  <div className="w-20 h-20 bg-brand-dark border-2 border-white/10 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,0,0,0.5)] z-10 group-hover:border-brand-primary transition-colors duration-300">
                    <Icon size={32} className="text-white group-hover:text-brand-primary transition-colors" />
                  </div>
                  <div className="mt-4 bg-white/10 backdrop-blur-md px-4 py-2 rounded-lg border border-white/5 text-center min-w-[120px]">
                    <span className="text-white font-bold text-sm block">{step}</span>
                    <span className="text-xs text-gray-400 block mt-1">Step 0{index + 1}</span>
                  </div>
                </div>
              );
            })}

            {/* Center Hub */}
            <div className="absolute inset-0 m-auto w-32 h-32 bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 rounded-full backdrop-blur-sm border border-white/10 flex flex-col items-center justify-center z-0">
               <RefreshCw size={40} className="text-white/80 animate-spin-reverse-slow mb-2" />
               <span className="text-xs text-brand-accent font-bold uppercase tracking-widest">ROI Loop</span>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDiagram;

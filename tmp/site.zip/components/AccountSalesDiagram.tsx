import React from 'react';
import { useApp } from '../context/AppContext';
import { TRANSLATIONS } from '../translations';
import { Timer, ShieldCheck, DollarSign, ArrowRight, TrendingUp } from 'lucide-react';

const AccountSalesDiagram: React.FC = () => {
  const { language } = useApp();
  const t = TRANSLATIONS[language].diagrams?.accountSales || TRANSLATIONS['en'].diagrams?.accountSales;

  const icons = [Timer, ShieldCheck, DollarSign];

  return (
    <div className="w-full max-w-6xl mx-auto p-1 rounded-3xl bg-gradient-to-br from-yellow-400 via-red-500 to-purple-600 shadow-2xl overflow-hidden relative mb-16">
      <div className="bg-brand-dark rounded-[22px] p-8 md:p-12 relative overflow-hidden">
        
        {/* Background Glows */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-lg bg-brand-primary/20 blur-[100px] rounded-full pointer-events-none"></div>

        {/* Floating Icons */}
        <div className="absolute top-10 left-10 animate-float-slow opacity-40 hidden md:block">
          <TrendingUp className="text-green-400" size={24} />
        </div>

        <div className="relative z-10">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-12 text-white tracking-wide uppercase">
            {t?.title}
          </h3>
          
          <div className="flex flex-col md:flex-row justify-between items-center gap-8 relative max-w-4xl mx-auto">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-12 left-0 w-full h-0.5 bg-gradient-to-r from-brand-secondary/50 to-brand-accent/50 -z-10"></div>

            {t?.steps.map((step: any, index: number) => {
              const Icon = icons[index];
              return (
                <div key={index} className="flex flex-col items-center text-center z-10 w-full md:w-1/3 group">
                  <div className="w-24 h-24 bg-gradient-to-br from-brand-secondary to-brand-accent rounded-full flex items-center justify-center mb-6 shadow-lg shadow-brand-secondary/30 transform group-hover:scale-110 transition-transform duration-300 border-4 border-brand-dark">
                    <Icon size={40} className="text-white" />
                  </div>
                  <h4 className="text-xl font-bold text-white mb-2">{step.title}</h4>
                  <p className="text-gray-400 text-sm">{step.desc}</p>
                  
                  {index < 2 && (
                    <div className="md:hidden mt-6 text-brand-secondary">
                      <ArrowRight size={24} className="transform rotate-90" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSalesDiagram;
